# ابزارینو v1.3.7+11

تغییرات این نسخه:
- تغییر package name به `mk.kadkhodai.abzar`.
- اضافه شدن keystore داخل سورس در مسیر `release_keystore/`.
- آماده‌سازی workflow برای ساخت خروجی release امضاشده با keystore داخل سورس.
- تنظیم workflow برای patch کردن Android namespace و applicationId.
- حفظ تغییرات UI نسخه v1.3.6 و حذف موقت بخش تاس.

نکته امنیتی:
- اطلاعات حساس keystore داخل فایل‌های پروژه قرار گرفته و در README تکرار نشده است.
