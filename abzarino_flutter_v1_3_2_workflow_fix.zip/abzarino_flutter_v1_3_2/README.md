# ابزارینو v1.3.2+6

نسخه اصلاحی build.

اصلاحات:
- رفع خطای sdkmanager در GitHub Actions با اضافه شدن android-actions/setup-android@v3.
- نصب امن Android SDK 35 از مسیر صحیح sdkmanager.
- حفظ compileSdk و targetSdk روی 35.
- حفظ اصلاح BatteryState.connectedNotCharging.
- خروجی APK/AAB با نسخه 1.3.2+6.

مسیر workflow:
`.github/workflows/build-apk.yml`
