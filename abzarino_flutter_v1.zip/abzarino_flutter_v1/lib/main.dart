import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const AbzarinoApp());

class AbzarinoApp extends StatelessWidget {
  const AbzarinoApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ابزارینو',
      theme: ThemeData(useMaterial3: true, fontFamily: 'Roboto', colorSchemeSeed: const Color(0xff2563eb)),
      home: const Directionality(textDirection: TextDirection.rtl, child: HomePage()),
    );
  }
}

class ToolItem {
  final String title, subtitle, group;
  final IconData icon;
  final Widget page;
  const ToolItem(this.title, this.subtitle, this.group, this.icon, this.page);
}

final tools = <ToolItem>[
  ToolItem('ماشین حساب', 'حساب سریع روزانه', 'محاسبات', Icons.calculate_rounded, const CalculatorPage()),
  ToolItem('تبدیل واحد', 'طول، وزن، دما و حجم', 'محاسبات', Icons.swap_horiz_rounded, const UnitPage()),
  ToolItem('درصدگیر', 'درصد، تخفیف و افزایش', 'محاسبات', Icons.percent_rounded, const PercentPage()),
  ToolItem('BMI', 'محاسبه شاخص توده بدن', 'سلامت', Icons.monitor_weight_rounded, const BmiPage()),
  ToolItem('سن‌سنج', 'اختلاف تاریخ تقریبی', 'محاسبات', Icons.cake_rounded, const AgePage()),
  ToolItem('یادداشت', 'ذخیره یادداشت‌های شخصی', 'نوشتار', Icons.note_alt_rounded, const NotesPage()),
  ToolItem('چک‌لیست', 'کارهای روزانه و خرید', 'نوشتار', Icons.checklist_rounded, const ChecklistPage()),
  ToolItem('رمزساز', 'ساخت رمز قوی و امن', 'امنیت', Icons.password_rounded, const PasswordPage()),
  ToolItem('تایمر', 'شمارش معکوس ساده', 'زمان', Icons.timer_rounded, const TimerPage()),
  ToolItem('کرنومتر', 'زمان‌سنج دقیق', 'زمان', Icons.av_timer_rounded, const StopwatchPageX()),
  ToolItem('شمارنده', 'شمارش دستی', 'زمان', Icons.add_circle_rounded, const CounterPage()),
  ToolItem('تاس', 'تاس مجازی', 'سرگرمی', Icons.casino_rounded, const DicePage()),
  ToolItem('شیر یا خط', 'انتخاب شانسی', 'سرگرمی', Icons.monetization_on_rounded, const CoinPage()),
  ToolItem('قرعه‌کشی', 'انتخاب تصادفی از لیست', 'سرگرمی', Icons.celebration_rounded, const LotteryPage()),
  ToolItem('اطلاعات دستگاه', 'اطلاعات پایه گوشی', 'گوشی', Icons.phone_android_rounded, const DeviceInfoPage()),
  ToolItem('ابزارهای فایل', 'PDF، QR، OCR و تصویر', 'فایل', Icons.folder_copy_rounded, const ComingSoonPage(title: 'ابزارهای فایل')),
  ToolItem('چراغ قوه و قطب‌نما', 'ابزارهای سخت‌افزاری', 'گوشی', Icons.flashlight_on_rounded, const ComingSoonPage(title: 'چراغ قوه و قطب‌نما')),
];

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage> {
  String q='';
  @override Widget build(BuildContext context){
    final filtered=tools.where((t)=>t.title.contains(q)||t.subtitle.contains(q)||t.group.contains(q)).toList();
    final groups=<String,List<ToolItem>>{}; for(final t in filtered){groups.putIfAbsent(t.group,()=>[]).add(t);} 
    return Scaffold(
      backgroundColor: const Color(0xfff6f8ff),
      body: SafeArea(child: CustomScrollView(slivers:[
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
          Container(padding: const EdgeInsets.all(20), decoration: box(const [Color(0xff1d4ed8),Color(0xff7c3aed)]), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
            Row(children:[Icon(Icons.apps_rounded,color:Colors.white,size:34),SizedBox(width:10),Text('ابزارینو',style:TextStyle(color:Colors.white,fontSize:30,fontWeight:FontWeight.w900))]),
            SizedBox(height:8),Text('جعبه ابزار کامل گوشی؛ سریع، سبک و آماده استفاده روزانه',style:TextStyle(color:Colors.white70,fontSize:14)),
          ])),
          const SizedBox(height:14),
          TextField(onChanged:(v)=>setState(()=>q=v), decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'جستجوی ابزار...', filled:true, fillColor:Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none))),
          const SizedBox(height:12),
          Row(children:[_stat('${tools.length}','ابزار'), const SizedBox(width:10), _stat('آفلاین','سریع'), const SizedBox(width:10), _stat('1.0.0','نسخه')]),
        ]))),
        ...groups.entries.map((e)=>SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.symmetric(horizontal:18,vertical:6), child: Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
          Text(e.key, style: const TextStyle(fontWeight: FontWeight.w900, fontSize:18)), const SizedBox(height:10),
          GridView.builder(shrinkWrap:true, physics: const NeverScrollableScrollPhysics(), itemCount:e.value.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,mainAxisSpacing:12,crossAxisSpacing:12,childAspectRatio:1.18), itemBuilder:(c,i)=>ToolCard(e.value[i])),
        ]))))
      ])),
    );
  }
  Widget _stat(String a,String b)=>Expanded(child:Container(padding:const EdgeInsets.all(12),decoration:softBox(),child:Column(children:[Text(a,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:17)),Text(b,style:const TextStyle(color:Colors.black54,fontSize:12))])));
}

class ToolCard extends StatelessWidget{final ToolItem t; const ToolCard(this.t,{super.key}); @override Widget build(BuildContext context)=>InkWell(borderRadius:BorderRadius.circular(24),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>Directionality(textDirection: TextDirection.rtl, child:t.page))),child:Container(padding:const EdgeInsets.all(16),decoration:softBox(),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Container(padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:const Color(0xffe0e7ff),borderRadius:BorderRadius.circular(16)),child:Icon(t.icon,color:const Color(0xff1d4ed8))),const Spacer(),Text(t.title,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:16)),const SizedBox(height:4),Text(t.subtitle,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.black54,fontSize:12))])));}

BoxDecoration box(List<Color> colors)=>BoxDecoration(gradient:LinearGradient(colors:colors),borderRadius:BorderRadius.circular(28),boxShadow:[BoxShadow(color:colors.first.withOpacity(.25),blurRadius:24,offset:const Offset(0,12))]);
BoxDecoration softBox()=>BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(24),boxShadow:[BoxShadow(color:Colors.black.withOpacity(.07),blurRadius:18,offset:const Offset(0,8))]);

class AppPage extends StatelessWidget{final String title; final Widget child; const AppPage({super.key,required this.title,required this.child}); @override Widget build(BuildContext context)=>Scaffold(backgroundColor:const Color(0xfff6f8ff),appBar:AppBar(title:Text(title),centerTitle:true,backgroundColor:Colors.transparent),body:SingleChildScrollView(padding:const EdgeInsets.all(18),child:child));}
TextField numField(TextEditingController c,String label)=>TextField(controller:c,keyboardType:TextInputType.number,decoration:InputDecoration(labelText:label,filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(18),borderSide:BorderSide.none)));

class CalculatorPage extends StatefulWidget{const CalculatorPage({super.key});@override State<CalculatorPage> createState()=>_CalculatorPageState();}
class _CalculatorPageState extends State<CalculatorPage>{String s='0'; void tap(String v){setState((){if(v=='C')s='0';else if(v=='⌫')s=s.length>1?s.substring(0,s.length-1):'0';else if(v=='=')s=calc(s);else{s=s=='0'?v:s+v;}});} @override Widget build(BuildContext c){final ks=['7','8','9','/','4','5','6','*','1','2','3','-','0','.','=','+','C','⌫'];return AppPage(title:'ماشین حساب',child:Column(children:[Container(width:double.infinity,padding:const EdgeInsets.all(22),decoration:softBox(),child:Text(s,textAlign:TextAlign.left,style:const TextStyle(fontSize:34,fontWeight:FontWeight.w900))),const SizedBox(height:16),GridView.count(crossAxisCount:4,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),mainAxisSpacing:10,crossAxisSpacing:10,children:ks.map((k)=>FilledButton.tonal(onPressed:()=>tap(k),child:Text(k,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)))).toList())]));}}
String calc(String e){try{final m=RegExp(r'^(-?\d+(?:\.\d+)?)([+\-*/])(-?\d+(?:\.\d+)?)$').firstMatch(e.replaceAll(' ','')); if(m==null)return 'فرمت ساده: 12+8'; final a=double.parse(m[1]!),b=double.parse(m[3]!); final op=m[2]; final r=op=='+'?a+b:op=='-'?a-b:op=='*'?a*b:a/b; return r.toStringAsFixed(r%1==0?0:2);}catch(_){return 'خطا';}}

class UnitPage extends StatefulWidget{const UnitPage({super.key});@override State<UnitPage> createState()=>_UnitPageState();}
class _UnitPageState extends State<UnitPage>{final c=TextEditingController();String type='متر به کیلومتر',out='';@override Widget build(BuildContext context)=>AppPage(title:'تبدیل واحد',child:Column(children:[DropdownButtonFormField(value:type,items:['متر به کیلومتر','کیلومتر به متر','کیلوگرم به گرم','گرم به کیلوگرم','سانتی‌گراد به فارنهایت','فارنهایت به سانتی‌گراد'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>type=v!),decoration:InputDecoration(filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(18),borderSide:BorderSide.none))),const SizedBox(height:12),numField(c,'مقدار'),const SizedBox(height:12),FilledButton(onPressed:(){final x=double.tryParse(c.text)??0; double r=switch(type){'متر به کیلومتر'=>x/1000,'کیلومتر به متر'=>x*1000,'کیلوگرم به گرم'=>x*1000,'گرم به کیلوگرم'=>x/1000,'سانتی‌گراد به فارنهایت'=>(x*9/5)+32,_=>(x-32)*5/9};setState(()=>out=r.toStringAsFixed(2));},child:const Text('تبدیل کن')),result(out)]));}
class PercentPage extends StatefulWidget{const PercentPage({super.key});@override State<PercentPage> createState()=>_PercentPageState();}
class _PercentPageState extends State<PercentPage>{final a=TextEditingController(),p=TextEditingController();String out='';@override Widget build(BuildContext context)=>AppPage(title:'درصدگیر',child:Column(children:[numField(a,'مبلغ / عدد اصلی'),const SizedBox(height:12),numField(p,'درصد'),const SizedBox(height:12),FilledButton(onPressed:(){final x=double.tryParse(a.text)??0,y=double.tryParse(p.text)??0;setState(()=>out='درصد: ${(x*y/100).toStringAsFixed(0)}\nبعد از تخفیف: ${(x-(x*y/100)).toStringAsFixed(0)}\nبعد از افزایش: ${(x+(x*y/100)).toStringAsFixed(0)}');},child:const Text('محاسبه')),result(out)]));}
class BmiPage extends StatefulWidget{const BmiPage({super.key});@override State<BmiPage> createState()=>_BmiPageState();}
class _BmiPageState extends State<BmiPage>{final w=TextEditingController(),h=TextEditingController();String out='';@override Widget build(BuildContext context)=>AppPage(title:'BMI',child:Column(children:[numField(w,'وزن - کیلوگرم'),const SizedBox(height:12),numField(h,'قد - سانتی‌متر'),const SizedBox(height:12),FilledButton(onPressed:(){final ww=double.tryParse(w.text)??0,hh=(double.tryParse(h.text)??0)/100;final b=ww/(hh*hh);setState(()=>out=hh>0?'BMI شما: ${b.toStringAsFixed(1)}':'قد را وارد کن');},child:const Text('محاسبه')),result(out)]));}
class AgePage extends StatefulWidget{const AgePage({super.key});@override State<AgePage> createState()=>_AgePageState();}
class _AgePageState extends State<AgePage>{DateTime? d;String out='';@override Widget build(BuildContext context)=>AppPage(title:'سن‌سنج',child:Column(children:[FilledButton(onPressed:()async{final x=await showDatePicker(context:context,firstDate:DateTime(1900),lastDate:DateTime.now(),initialDate:DateTime(2000)); if(x!=null){final days=DateTime.now().difference(x).inDays;setState(()=>out='تقریباً ${days~/365} سال، ${(days%365)~/30} ماه و ${days%30} روز');}},child:const Text('انتخاب تاریخ تولد')),result(out)]));}
Widget result(String s)=>s.isEmpty?const SizedBox.shrink():Container(width:double.infinity,margin:const EdgeInsets.only(top:16),padding:const EdgeInsets.all(18),decoration:softBox(),child:Text(s,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)));

class NotesPage extends StatefulWidget{const NotesPage({super.key});@override State<NotesPage> createState()=>_NotesPageState();}
class _NotesPageState extends State<NotesPage>{final c=TextEditingController();List<String> notes=[];@override void initState(){super.initState();load();}Future load()async{final p=await SharedPreferences.getInstance();setState(()=>notes=p.getStringList('notes')??[]);}Future save()async{final p=await SharedPreferences.getInstance();p.setStringList('notes',notes);} @override Widget build(BuildContext context)=>AppPage(title:'یادداشت',child:Column(children:[TextField(controller:c,maxLines:3,decoration:InputDecoration(hintText:'یادداشت جدید...',filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(18),borderSide:BorderSide.none))),const SizedBox(height:10),FilledButton(onPressed:(){if(c.text.trim().isNotEmpty){setState(()=>notes.insert(0,c.text.trim()));c.clear();save();}},child:const Text('ذخیره')),for(final n in notes)Card(child:ListTile(title:Text(n),trailing:IconButton(icon:const Icon(Icons.delete),onPressed:(){setState(()=>notes.remove(n));save();})))]));}
class ChecklistPage extends StatefulWidget{const ChecklistPage({super.key});@override State<ChecklistPage> createState()=>_ChecklistPageState();}
class _ChecklistPageState extends State<ChecklistPage>{final c=TextEditingController();List<String> items=[];Set<String> done={};@override void initState(){super.initState();load();}Future load()async{final p=await SharedPreferences.getInstance();setState((){items=p.getStringList('items')??[];done=(p.getStringList('done')??[]).toSet();});}Future save()async{final p=await SharedPreferences.getInstance();p.setStringList('items',items);p.setStringList('done',done.toList());}@override Widget build(BuildContext context)=>AppPage(title:'چک‌لیست',child:Column(children:[Row(children:[Expanded(child:TextField(controller:c,decoration:InputDecoration(hintText:'مورد جدید',filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(18),borderSide:BorderSide.none)))),IconButton.filled(onPressed:(){if(c.text.trim().isNotEmpty){setState(()=>items.add(c.text.trim()));c.clear();save();}},icon:const Icon(Icons.add))]),for(final it in items)CheckboxListTile(value:done.contains(it),title:Text(it),onChanged:(v){setState(()=>v!?done.add(it):done.remove(it));save();})]));}
class PasswordPage extends StatefulWidget{const PasswordPage({super.key});@override State<PasswordPage> createState()=>_PasswordPageState();}
class _PasswordPageState extends State<PasswordPage>{String p='';@override Widget build(BuildContext context)=>AppPage(title:'رمزساز',child:Column(children:[FilledButton(onPressed:(){const chars='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#%&*';final r=Random.secure();setState(()=>p=List.generate(16,(_)=>chars[r.nextInt(chars.length)]).join());},child:const Text('ساخت رمز ۱۶ کاراکتری')),if(p.isNotEmpty)ListTile(title:SelectableText(p,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:20)),trailing:IconButton(icon:const Icon(Icons.copy),onPressed:()=>Clipboard.setData(ClipboardData(text:p))))]));}

class TimerPage extends StatefulWidget{const TimerPage({super.key});@override State<TimerPage> createState()=>_TimerPageState();}
class _TimerPageState extends State<TimerPage>{int sec=60;Timer? t;@override Widget build(BuildContext context)=>AppPage(title:'تایمر',child:Column(children:[Text('$sec',style:const TextStyle(fontSize:56,fontWeight:FontWeight.w900)),Slider(value:sec.toDouble(),min:10,max:3600,divisions:359,onChanged:t==null?(v)=>setState(()=>sec=v.round()):null),Row(mainAxisAlignment:MainAxisAlignment.center,children:[FilledButton(onPressed:(){t?.cancel();t=Timer.periodic(const Duration(seconds:1),(_){if(sec<=0){t?.cancel();t=null;}else{setState(()=>sec--);}});},child:const Text('شروع')),const SizedBox(width:10),OutlinedButton(onPressed:(){t?.cancel();setState((){t=null;sec=60;});},child:const Text('ریست'))]) ]));}
class StopwatchPageX extends StatefulWidget{const StopwatchPageX({super.key});@override State<StopwatchPageX> createState()=>_StopwatchPageXState();}
class _StopwatchPageXState extends State<StopwatchPageX>{final sw=Stopwatch();Timer? t;@override Widget build(BuildContext context)=>AppPage(title:'کرنومتر',child:Column(children:[Text('${sw.elapsed.inMinutes.toString().padLeft(2,'0')}:${(sw.elapsed.inSeconds%60).toString().padLeft(2,'0')}.${(sw.elapsed.inMilliseconds%1000~/10).toString().padLeft(2,'0')}',style:const TextStyle(fontSize:44,fontWeight:FontWeight.w900)),Row(mainAxisAlignment:MainAxisAlignment.center,children:[FilledButton(onPressed:(){sw.start();t??=Timer.periodic(const Duration(milliseconds:50),(_)=>setState((){}));},child:const Text('شروع')),const SizedBox(width:8),OutlinedButton(onPressed:(){sw.stop();},child:const Text('توقف')),const SizedBox(width:8),OutlinedButton(onPressed:(){sw.reset();setState((){});},child:const Text('ریست'))]) ]));}
class CounterPage extends StatefulWidget{const CounterPage({super.key});@override State<CounterPage> createState()=>_CounterPageState();}
class _CounterPageState extends State<CounterPage>{int n=0;@override Widget build(BuildContext context)=>AppPage(title:'شمارنده',child:Column(children:[Text('$n',style:const TextStyle(fontSize:70,fontWeight:FontWeight.w900)),Row(mainAxisAlignment:MainAxisAlignment.center,children:[IconButton.filled(onPressed:()=>setState(()=>n++),icon:const Icon(Icons.add)),const SizedBox(width:18),IconButton.outlined(onPressed:()=>setState(()=>n=max(0,n-1)),icon:const Icon(Icons.remove))]) ]));}
class DicePage extends StatefulWidget{const DicePage({super.key});@override State<DicePage> createState()=>_DicePageState();} class _DicePageState extends State<DicePage>{int n=1;@override Widget build(BuildContext context)=>AppPage(title:'تاس',child:Center(child:Column(children:[Text('$n',style:const TextStyle(fontSize:90,fontWeight:FontWeight.w900)),FilledButton(onPressed:()=>setState(()=>n=Random().nextInt(6)+1),child:const Text('بنداز'))])));}
class CoinPage extends StatefulWidget{const CoinPage({super.key});@override State<CoinPage> createState()=>_CoinPageState();} class _CoinPageState extends State<CoinPage>{String n='؟';@override Widget build(BuildContext context)=>AppPage(title:'شیر یا خط',child:Center(child:Column(children:[Text(n,style:const TextStyle(fontSize:60,fontWeight:FontWeight.w900)),FilledButton(onPressed:()=>setState(()=>n=Random().nextBool()?'شیر':'خط'),child:const Text('شروع'))])));}
class LotteryPage extends StatefulWidget{const LotteryPage({super.key});@override State<LotteryPage> createState()=>_LotteryPageState();} class _LotteryPageState extends State<LotteryPage>{final c=TextEditingController();String out='';@override Widget build(BuildContext context)=>AppPage(title:'قرعه‌کشی',child:Column(children:[TextField(controller:c,maxLines:6,decoration:InputDecoration(hintText:'هر گزینه را در یک خط بنویس',filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(18),borderSide:BorderSide.none))),const SizedBox(height:10),FilledButton(onPressed:(){final list=c.text.split('\n').map((e)=>e.trim()).where((e)=>e.isNotEmpty).toList();setState(()=>out=list.isEmpty?'گزینه‌ای وارد نشده':list[Random().nextInt(list.length)]);},child:const Text('انتخاب کن')),result(out)]));}
class DeviceInfoPage extends StatelessWidget{const DeviceInfoPage({super.key});@override Widget build(BuildContext context)=>AppPage(title:'اطلاعات دستگاه',child:Column(children:const [ListTile(leading:Icon(Icons.android),title:Text('سیستم عامل'),subtitle:Text('Android / Flutter')),ListTile(leading:Icon(Icons.language),title:Text('زبان برنامه'),subtitle:Text('فارسی و راست‌چین')),ListTile(leading:Icon(Icons.storage),title:Text('ذخیره‌سازی'),subtitle:Text('یادداشت و چک‌لیست روی گوشی ذخیره می‌شود'))]));}
class ComingSoonPage extends StatelessWidget{final String title;const ComingSoonPage({super.key,required this.title});@override Widget build(BuildContext context)=>AppPage(title:title,child:Container(width:double.infinity,padding:const EdgeInsets.all(24),decoration:softBox(),child:const Text('این بخش در نسخه بعد با دسترسی‌های لازم گوشی و پکیج‌های اختصاصی کامل می‌شود. نسخه فعلی روی ابزارهای سریع و آفلاین تمرکز دارد.',style:TextStyle(fontSize:16,height:1.8))));}
