# ابزارینو v1.3.8+12

اصلاحات:
- رفع خطای Gradle مربوط به قرار گرفتن keystoreProperties قبل از plugins {}.
- کد keystoreProperties در build.gradle بعد از plugins {} اضافه می‌شود.
- package name حفظ شد: mk.kadkhodai.abzar
- امضای release با keystore داخل سورس حفظ شد.
- نسخه خروجی: 1.3.8+12
