# ابزارینو v1.3.1+5

نسخه اصلاحی برای رفع خطای Build GitHub Actions.

## تغییرات
- رفع خطای BatteryState.connectedNotCharging در battery_plus
- اضافه شدن default case برای جلوگیری از خطای build در نسخه‌های بعدی battery_plus
- اجبار compileSdk و targetSdk به 35 در Workflow
- نصب Android SDK 35 در GitHub Actions
- به‌روزرسانی خروجی build به 1.3.1+5

## Workflow
مسیر workflow:

`.github/workflows/build-apk.yml`

