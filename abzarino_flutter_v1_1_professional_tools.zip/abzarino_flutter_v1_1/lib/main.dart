import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const AbzarinoApp());

class AbzarinoApp extends StatelessWidget {
  const AbzarinoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ابزارینو',
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: const Color(0xfff7f8ff),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xff6d5dfc),
          brightness: Brightness.light,
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 0,
          backgroundColor: Colors.transparent,
          foregroundColor: Color(0xff182033),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class ToolItem {
  final String title;
  final String subtitle;
  final String group;
  final IconData icon;
  final List<Color> colors;
  final WidgetBuilder builder;
  final bool featured;

  const ToolItem({
    required this.title,
    required this.subtitle,
    required this.group,
    required this.icon,
    required this.colors,
    required this.builder,
    this.featured = false,
  });
}

final List<ToolItem> tools = [
  ToolItem(title: 'ماشین حساب', subtitle: 'معمولی و مهندسی کامل', group: 'محاسبات', icon: Icons.calculate_rounded, colors: const [Color(0xff6d5dfc), Color(0xff22d3ee)], builder: (_) => const CalculatorPage(), featured: true),
  ToolItem(title: 'تبدیل واحد', subtitle: 'طول، وزن، دما و حجم', group: 'محاسبات', icon: Icons.swap_horiz_rounded, colors: const [Color(0xff00b894), Color(0xff55efc4)], builder: (_) => const UnitPage()),
  ToolItem(title: 'درصدگیر', subtitle: 'درصد، تخفیف و افزایش', group: 'محاسبات', icon: Icons.percent_rounded, colors: const [Color(0xffff7675), Color(0xffffb88c)], builder: (_) => const PercentPage()),
  ToolItem(title: 'سن‌سنج شمسی', subtitle: 'تقویم جلالی و محاسبه دقیق', group: 'محاسبات', icon: Icons.cake_rounded, colors: const [Color(0xffff8a00), Color(0xffffc371)], builder: (_) => const AgePage(), featured: true),
  ToolItem(title: 'BMI', subtitle: 'شاخص توده بدن', group: 'سلامت', icon: Icons.monitor_weight_rounded, colors: const [Color(0xff11998e), Color(0xff38ef7d)], builder: (_) => const BmiPage()),
  ToolItem(title: 'یادداشت', subtitle: 'تاریخ شمسی و ذخیره آفلاین', group: 'نوشتار', icon: Icons.note_alt_rounded, colors: const [Color(0xffa18cd1), Color(0xfffbc2eb)], builder: (_) => const NotesPage(), featured: true),
  ToolItem(title: 'چک‌لیست', subtitle: 'کارهای روزانه و خرید', group: 'نوشتار', icon: Icons.checklist_rounded, colors: const [Color(0xff4facfe), Color(0xff00f2fe)], builder: (_) => const ChecklistPage()),
  ToolItem(title: 'رمزساز', subtitle: 'ذخیره رمز با عنوان و کلمه کلیدی', group: 'امنیت', icon: Icons.password_rounded, colors: const [Color(0xff141e30), Color(0xff243b55)], builder: (_) => const PasswordPage(), featured: true),
  ToolItem(title: 'تایمر', subtitle: 'شمارش معکوس روان', group: 'زمان', icon: Icons.timer_rounded, colors: const [Color(0xffff9a9e), Color(0xfffecfef)], builder: (_) => const TimerPage()),
  ToolItem(title: 'کرنومتر', subtitle: 'زمان‌سنج دقیق', group: 'زمان', icon: Icons.av_timer_rounded, colors: const [Color(0xff667eea), Color(0xff764ba2)], builder: (_) => const StopwatchPageX()),
  ToolItem(title: 'شمارنده', subtitle: 'شمارش سریع دستی', group: 'زمان', icon: Icons.add_circle_rounded, colors: const [Color(0xffff512f), Color(0xffdd2476)], builder: (_) => const CounterPage()),
  ToolItem(title: 'تاس واقعی', subtitle: 'چرخش روان و ظاهر سه‌بعدی', group: 'سرگرمی', icon: Icons.casino_rounded, colors: const [Color(0xfff7971e), Color(0xffffd200)], builder: (_) => const DicePage(), featured: true),
  ToolItem(title: 'شیر یا خط', subtitle: 'سکه متحرک و پرتاب واقعی‌تر', group: 'سرگرمی', icon: Icons.monetization_on_rounded, colors: const [Color(0xfff6d365), Color(0xfffda085)], builder: (_) => const CoinPage(), featured: true),
  ToolItem(title: 'قرعه‌کشی', subtitle: 'رولت، چند برنده، ذخیره نتیجه', group: 'سرگرمی', icon: Icons.celebration_rounded, colors: const [Color(0xfffa709a), Color(0xffffc371)], builder: (_) => const LotteryPage(), featured: true),
  ToolItem(title: 'اطلاعات دستگاه', subtitle: 'اطلاعات پایه برنامه و گوشی', group: 'گوشی', icon: Icons.phone_android_rounded, colors: const [Color(0xff36d1dc), Color(0xff5b86e5)], builder: (_) => const DeviceInfoPage()),
  ToolItem(title: 'ابزارهای فایل', subtitle: 'PDF، QR، OCR و تصویر', group: 'فایل', icon: Icons.folder_copy_rounded, colors: const [Color(0xff30cfd0), Color(0xff330867)], builder: (_) => const ComingSoonPage(title: 'ابزارهای فایل')),
  ToolItem(title: 'چراغ قوه و قطب‌نما', subtitle: 'نسخه سخت‌افزاری آینده', group: 'گوشی', icon: Icons.flashlight_on_rounded, colors: const [Color(0xffffafbd), Color(0xffffc3a0)], builder: (_) => const ComingSoonPage(title: 'چراغ قوه و قطب‌نما')),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String query = '';
  List<String> recent = [];

  @override
  void initState() {
    super.initState();
    _loadRecent();
  }

  Future<void> _loadRecent() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => recent = prefs.getStringList('recent_tools') ?? []);
  }

  Future<void> _open(ToolItem tool) async {
    final prefs = await SharedPreferences.getInstance();
    final next = [tool.title, ...recent.where((e) => e != tool.title)].take(6).toList();
    await prefs.setStringList('recent_tools', next);
    if (mounted) setState(() => recent = next);
    if (!mounted) return;
    Navigator.push(context, MaterialPageRoute(builder: tool.builder));
  }

  @override
  Widget build(BuildContext context) {
    final filtered = tools.where((t) => t.title.contains(query) || t.subtitle.contains(query) || t.group.contains(query)).toList();
    final groups = <String, List<ToolItem>>{};
    for (final item in filtered) {
      groups.putIfAbsent(item.group, () => []).add(item);
    }
    final recentTools = <ToolItem>[];
    for (final title in recent) {
      final match = tools.where((t) => t.title == title);
      if (match.isNotEmpty) recentTools.add(match.first);
    }
    final featured = tools.where((t) => t.featured).toList();

    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(22),
                      decoration: gradientDecoration(const [Color(0xff6d5dfc), Color(0xffff6b9d)], radius: 32),
                      child: Stack(
                        children: [
                          Positioned(left: -20, top: -20, child: _glowCircle(110, Colors.white.withOpacity(.12))),
                          Positioned(right: -18, bottom: -25, child: _glowCircle(95, Colors.white.withOpacity(.10))),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(color: Colors.white.withOpacity(.20), borderRadius: BorderRadius.circular(20)),
                                    child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 32),
                                  ),
                                  const SizedBox(width: 12),
                                  const Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text('ابزارینو', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900)),
                                        SizedBox(height: 3),
                                        Text('جعبه ابزار کامل، شاد و حرفه‌ای گوشی', style: TextStyle(color: Colors.white70, fontSize: 13)),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 18),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
                                child: TextField(
                                  onChanged: (value) => setState(() => query = value.trim()),
                                  decoration: const InputDecoration(
                                    icon: Icon(Icons.search_rounded),
                                    hintText: 'جستجوی ابزار مورد نیاز...',
                                    border: InputBorder.none,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        _miniStat('${tools.length}', 'ابزار'),
                        const SizedBox(width: 10),
                        _miniStat('شمسی', 'تقویم'),
                        const SizedBox(width: 10),
                        _miniStat('1.1.0', 'نسخه'),
                      ],
                    ),
                    if (recentTools.isNotEmpty) ...[
                      const SizedBox(height: 20),
                      _sectionTitle('آخرین ابزارهای استفاده‌شده', Icons.history_rounded),
                      const SizedBox(height: 10),
                      SizedBox(
                        height: 112,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: recentTools.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 12),
                          itemBuilder: (_, i) => RecentToolCard(tool: recentTools[i], onTap: () => _open(recentTools[i])),
                        ),
                      ),
                    ],
                    const SizedBox(height: 20),
                    _sectionTitle('ابزارهای پرکاربرد', Icons.local_fire_department_rounded),
                    const SizedBox(height: 10),
                    SizedBox(
                      height: 178,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: featured.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 14),
                        itemBuilder: (_, i) => FeaturedToolCard(tool: featured[i], onTap: () => _open(featured[i])),
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            ),
            ...groups.entries.map((entry) {
              return SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _sectionTitle(entry.key, Icons.grid_view_rounded),
                      const SizedBox(height: 10),
                      GridView.builder(
                        itemCount: entry.value.length,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          mainAxisSpacing: 13,
                          crossAxisSpacing: 13,
                          childAspectRatio: 1.06,
                        ),
                        itemBuilder: (_, i) => ToolCard(tool: entry.value[i], onTap: () => _open(entry.value[i])),
                      ),
                    ],
                  ),
                ),
              );
            }),
            const SliverToBoxAdapter(child: SizedBox(height: 24)),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: const Color(0xff6d5dfc), size: 21),
        const SizedBox(width: 8),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: Color(0xff182033))),
      ],
    );
  }

  Widget _miniStat(String value, String label) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: softDecoration(radius: 22),
        child: Column(
          children: [
            Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: Color(0xff182033))),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}

class FeaturedToolCard extends StatelessWidget {
  final ToolItem tool;
  final VoidCallback onTap;
  const FeaturedToolCard({super.key, required this.tool, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 240,
      child: InkWell(
        borderRadius: BorderRadius.circular(30),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: gradientDecoration(tool.colors, radius: 30),
          child: Stack(
            children: [
              Positioned(left: -22, top: -18, child: _glowCircle(90, Colors.white.withOpacity(.14))),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(13),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(.24), borderRadius: BorderRadius.circular(22)),
                    child: Icon(tool.icon, color: Colors.white, size: 34),
                  ),
                  const Spacer(),
                  Text(tool.title, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 6),
                  Text(tool.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, height: 1.35)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class RecentToolCard extends StatelessWidget {
  final ToolItem tool;
  final VoidCallback onTap;
  const RecentToolCard({super.key, required this.tool, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 190,
      child: InkWell(
        borderRadius: BorderRadius.circular(26),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: softDecoration(radius: 26),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: gradientDecoration(tool.colors, radius: 18),
                child: Icon(tool.icon, color: Colors.white),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(tool.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 4),
                    Text(tool.group, style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class ToolCard extends StatelessWidget {
  final ToolItem tool;
  final VoidCallback onTap;
  const ToolCard({super.key, required this.tool, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(28),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: softDecoration(radius: 28),
        child: Stack(
          children: [
            Positioned(left: -18, top: -18, child: _glowCircle(70, tool.colors.last.withOpacity(.18))),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: gradientDecoration(tool.colors, radius: 20),
                  child: Icon(tool.icon, color: Colors.white, size: 27),
                ),
                const Spacer(),
                Text(tool.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: Color(0xff182033))),
                const SizedBox(height: 5),
                Text(tool.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.grey.shade600, fontSize: 12, height: 1.25)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class AppPage extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<Color> colors;
  final Widget child;
  final EdgeInsets padding;

  const AppPage({
    super.key,
    required this.title,
    required this.icon,
    required this.colors,
    required this.child,
    this.padding = const EdgeInsets.all(18),
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                children: [
                  IconButton.filledTonal(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: gradientDecoration(colors, radius: 24),
                      child: Row(
                        children: [
                          Icon(icon, color: Colors.white),
                          const SizedBox(width: 10),
                          Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900))),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(child: SingleChildScrollView(padding: padding, child: child)),
          ],
        ),
      ),
    );
  }
}

BoxDecoration gradientDecoration(List<Color> colors, {double radius = 24}) {
  return BoxDecoration(
    gradient: LinearGradient(colors: colors, begin: Alignment.topRight, end: Alignment.bottomLeft),
    borderRadius: BorderRadius.circular(radius),
    boxShadow: [BoxShadow(color: colors.first.withOpacity(.22), blurRadius: 24, offset: const Offset(0, 12))],
  );
}

BoxDecoration softDecoration({double radius = 24}) {
  return BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: Colors.white.withOpacity(.85), width: 1),
    boxShadow: [
      BoxShadow(color: Colors.black.withOpacity(.065), blurRadius: 24, offset: const Offset(0, 12)),
      BoxShadow(color: Colors.white.withOpacity(.8), blurRadius: 10, offset: const Offset(-4, -4)),
    ],
  );
}

Widget _glowCircle(double size, Color color) {
  return Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, color: color));
}

InputDecoration fieldDecoration(String label, {String? hint, IconData? icon}) {
  return InputDecoration(
    labelText: label,
    hintText: hint,
    prefixIcon: icon == null ? null : Icon(icon),
    filled: true,
    fillColor: Colors.white,
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
  );
}

TextField numField(TextEditingController controller, String label, {IconData? icon}) {
  return TextField(
    controller: controller,
    keyboardType: const TextInputType.numberWithOptions(decimal: true),
    decoration: fieldDecoration(label, icon: icon),
  );
}

Widget resultCard(String title, String value, {IconData icon = Icons.done_all_rounded, List<Color> colors = const [Color(0xff6d5dfc), Color(0xff22d3ee)]}) {
  if (value.trim().isEmpty) return const SizedBox.shrink();
  return Container(
    width: double.infinity,
    margin: const EdgeInsets.only(top: 14),
    padding: const EdgeInsets.all(18),
    decoration: gradientDecoration(colors, radius: 24),
    child: Row(
      children: [
        Icon(icon, color: Colors.white),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 4),
            SelectableText(value, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
          ]),
        ),
      ],
    ),
  );
}

String faNum(Object value) {
  const en = '0123456789';
  const fa = '۰۱۲۳۴۵۶۷۸۹';
  var s = value.toString();
  for (var i = 0; i < en.length; i++) {
    s = s.replaceAll(en[i], fa[i]);
  }
  return s;
}

// ------------------------- Persian / Jalali date -------------------------
class JDate {
  final int y;
  final int m;
  final int d;
  const JDate(this.y, this.m, this.d);

  String get monthName => PersianDateUtils.monthNames[m - 1];
  String get formatted => '${faNum(y)}/${faNum(m.toString().padLeft(2, '0'))}/${faNum(d.toString().padLeft(2, '0'))}';
  String get longText => '${faNum(d)} $monthName ${faNum(y)}';

  Map<String, dynamic> toJson() => {'y': y, 'm': m, 'd': d};
  static JDate fromJson(Map<String, dynamic> json) => JDate(json['y'] as int, json['m'] as int, json['d'] as int);
}

class PersianDateUtils {
  static const monthNames = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
  static const weekDays = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];

  static JDate today() {
    final now = DateTime.now();
    return gregorianToJalali(now.year, now.month, now.day);
  }

  static bool isGregorianLeap(int year) {
    return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
  }

  static bool isJalaliLeap(int jy) {
    final a = jy > 0 ? 474 : 473;
    final b = ((jy - a) % 2820) + 474;
    return ((b + 38) * 682) % 2816 < 682;
  }

  static int monthLength(int jy, int jm) {
    if (jm <= 6) return 31;
    if (jm <= 11) return 30;
    return isJalaliLeap(jy) ? 30 : 29;
  }

  static JDate gregorianToJalali(int gy, int gm, int gd) {
    final gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    final gy2 = gy - 1600;
    final gm2 = gm - 1;
    final gd2 = gd - 1;
    var gdn = 365 * gy2 + ((gy2 + 3) ~/ 4) - ((gy2 + 99) ~/ 100) + ((gy2 + 399) ~/ 400);
    gdn += gdm[gm2] + gd2;
    if (gm2 > 1 && isGregorianLeap(gy)) gdn++;

    var jdn = gdn - 79;
    final jnp = jdn ~/ 12053;
    jdn %= 12053;
    var jy = 979 + 33 * jnp + 4 * (jdn ~/ 1461);
    jdn %= 1461;
    if (jdn >= 366) {
      jy += (jdn - 1) ~/ 365;
      jdn = (jdn - 1) % 365;
    }
    var jm = 0;
    final jdm = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
    while (jm < 11 && jdn >= jdm[jm]) {
      jdn -= jdm[jm];
      jm++;
    }
    return JDate(jy, jm + 1, jdn + 1);
  }

  static DateTime jalaliToGregorian(int jy, int jm, int jd) {
    final jdm = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
    jy -= 979;
    jm -= 1;
    jd -= 1;
    var jdn = 365 * jy + (jy ~/ 33) * 8 + (((jy % 33) + 3) ~/ 4);
    for (var i = 0; i < jm; i++) {
      jdn += jdm[i];
    }
    jdn += jd;
    var gdn = jdn + 79;
    var gy = 1600 + 400 * (gdn ~/ 146097);
    gdn %= 146097;
    var leap = true;
    if (gdn >= 36525) {
      gdn--;
      gy += 100 * (gdn ~/ 36524);
      gdn %= 36524;
      if (gdn >= 365) {
        gdn++;
      } else {
        leap = false;
      }
    }
    gy += 4 * (gdn ~/ 1461);
    gdn %= 1461;
    if (gdn >= 366) {
      leap = false;
      gdn--;
      gy += gdn ~/ 365;
      gdn %= 365;
    }
    final gdMonth = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    var gm = 0;
    while (gm < 11 && gdn >= gdMonth[gm]) {
      gdn -= gdMonth[gm];
      gm++;
    }
    return DateTime(gy, gm + 1, gdn + 1);
  }

  static int firstWeekdayIndex(int jy, int jm) {
    final g = jalaliToGregorian(jy, jm, 1);
    return (g.weekday + 1) % 7; // Saturday = 0
  }
}

Future<JDate?> showPersianDatePickerDialog(BuildContext context, {JDate? initial, int minYear = 1300, int maxYear = 1505}) async {
  final today = PersianDateUtils.today();
  var selected = initial ?? today;
  var viewYear = selected.y;
  var viewMonth = selected.m;
  return showDialog<JDate>(
    context: context,
    builder: (dialogContext) {
      return StatefulBuilder(
        builder: (context, setState) {
          final days = PersianDateUtils.monthLength(viewYear, viewMonth);
          final first = PersianDateUtils.firstWeekdayIndex(viewYear, viewMonth);
          return Dialog(
            insetPadding: const EdgeInsets.all(18),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: softDecoration(radius: 28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: gradientDecoration(const [Color(0xff6d5dfc), Color(0xffff6b9d)], radius: 22),
                    child: Row(
                      children: [
                        const Icon(Icons.calendar_month_rounded, color: Colors.white),
                        const SizedBox(width: 8),
                        const Expanded(child: Text('تقویم شمسی', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18))),
                        TextButton(
                          onPressed: () => setState(() {
                            viewYear = today.y;
                            viewMonth = today.m;
                            selected = today;
                          }),
                          child: const Text('امروز', style: TextStyle(color: Colors.white)),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      IconButton.filledTonal(
                        onPressed: () => setState(() {
                          viewMonth--;
                          if (viewMonth < 1) {
                            viewMonth = 12;
                            viewYear--;
                          }
                        }),
                        icon: const Icon(Icons.chevron_right_rounded),
                      ),
                      Expanded(
                        child: Center(
                          child: Text('${PersianDateUtils.monthNames[viewMonth - 1]} ${faNum(viewYear)}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                        ),
                      ),
                      IconButton.filledTonal(
                        onPressed: () => setState(() {
                          viewMonth++;
                          if (viewMonth > 12) {
                            viewMonth = 1;
                            viewYear++;
                          }
                        }),
                        icon: const Icon(Icons.chevron_left_rounded),
                      ),
                    ],
                  ),
                  Row(
                    children: PersianDateUtils.weekDays.map((e) => Expanded(child: Center(child: Text(e, style: TextStyle(fontWeight: FontWeight.w900, color: Colors.grey.shade600))))).toList(),
                  ),
                  const SizedBox(height: 6),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7, mainAxisSpacing: 6, crossAxisSpacing: 6),
                    itemCount: first + days,
                    itemBuilder: (_, index) {
                      if (index < first) return const SizedBox.shrink();
                      final day = index - first + 1;
                      final active = selected.y == viewYear && selected.m == viewMonth && selected.d == day;
                      return InkWell(
                        borderRadius: BorderRadius.circular(14),
                        onTap: () => setState(() => selected = JDate(viewYear, viewMonth, day)),
                        child: Container(
                          decoration: active ? gradientDecoration(const [Color(0xff6d5dfc), Color(0xff22d3ee)], radius: 14) : BoxDecoration(color: const Color(0xfff3f4ff), borderRadius: BorderRadius.circular(14)),
                          child: Center(child: Text(faNum(day), style: TextStyle(fontWeight: FontWeight.w900, color: active ? Colors.white : const Color(0xff182033)))),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('انصراف'))),
                      const SizedBox(width: 10),
                      Expanded(child: FilledButton(onPressed: () => Navigator.pop(dialogContext, selected), child: const Text('تایید'))),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}

class PersianDateField extends StatelessWidget {
  final String label;
  final JDate? value;
  final ValueChanged<JDate> onChanged;
  final IconData icon;

  const PersianDateField({super.key, required this.label, required this.value, required this.onChanged, this.icon = Icons.calendar_month_rounded});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: () async {
        final picked = await showPersianDatePickerDialog(context, initial: value);
        if (picked != null) onChanged(picked);
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: softDecoration(radius: 24),
        child: Row(
          children: [
            Container(padding: const EdgeInsets.all(12), decoration: gradientDecoration(const [Color(0xff6d5dfc), Color(0xff22d3ee)], radius: 18), child: Icon(icon, color: Colors.white)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                const SizedBox(height: 4),
                Text(value?.longText ?? 'انتخاب تاریخ شمسی', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
              ]),
            ),
            const Icon(Icons.keyboard_arrow_down_rounded),
          ],
        ),
      ),
    );
  }
}

// ------------------------- Calculator -------------------------
class CalculatorPage extends StatefulWidget {
  const CalculatorPage({super.key});
  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  String expression = '';
  String preview = '۰';
  bool scientific = false;
  bool degree = true;
  final List<String> history = [];

  @override
  Widget build(BuildContext context) {
    final normal = ['C', '⌫', '(', ')', '۷', '۸', '۹', '÷', '۴', '۵', '۶', '×', '۱', '۲', '۳', '-', '۰', '.', '%', '+'];
    final sci = ['sin', 'cos', 'tan', 'log', 'ln', '√', '^', 'π', 'e', '!', 'asin', 'acos', 'atan', 'abs', '±'];
    final keys = scientific ? [...sci, ...normal, '='] : [...normal, '='];

    return AppPage(
      title: 'ماشین حساب حرفه‌ای',
      icon: Icons.calculate_rounded,
      colors: const [Color(0xff6d5dfc), Color(0xff22d3ee)],
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: gradientDecoration(const [Color(0xff182033), Color(0xff334155)], radius: 30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    ChoiceChip(label: Text(scientific ? 'مهندسی' : 'معمولی'), selected: scientific, onSelected: (_) => setState(() => scientific = !scientific)),
                    const SizedBox(width: 8),
                    ChoiceChip(label: Text(degree ? 'درجه' : 'رادیان'), selected: degree, onSelected: (_) => setState(() => degree = !degree)),
                    const Spacer(),
                    IconButton(onPressed: _copyResult, icon: const Icon(Icons.copy_rounded, color: Colors.white)),
                  ],
                ),
                const SizedBox(height: 12),
                SingleChildScrollView(
                  reverse: true,
                  scrollDirection: Axis.horizontal,
                  child: Text(expression.isEmpty ? '۰' : faNum(expression), textDirection: TextDirection.ltr, style: const TextStyle(color: Colors.white70, fontSize: 20, fontWeight: FontWeight.w600)),
                ),
                const SizedBox(height: 8),
                SingleChildScrollView(
                  reverse: true,
                  scrollDirection: Axis.horizontal,
                  child: Text(preview, textDirection: TextDirection.ltr, style: const TextStyle(color: Colors.white, fontSize: 38, fontWeight: FontWeight.w900)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          GridView.builder(
            itemCount: keys.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: scientific ? 5 : 4, mainAxisSpacing: 9, crossAxisSpacing: 9, childAspectRatio: scientific ? 1.18 : 1.05),
            itemBuilder: (_, i) => _calcButton(keys[i]),
          ),
          if (history.isNotEmpty) ...[
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: softDecoration(radius: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [const Icon(Icons.history_rounded), const SizedBox(width: 8), const Text('تاریخچه محاسبات', style: TextStyle(fontWeight: FontWeight.w900)), const Spacer(), TextButton(onPressed: () => setState(() => history.clear()), child: const Text('پاک کردن'))]),
                  ...history.take(6).map((h) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: SelectableText(faNum(h), textDirection: TextDirection.ltr))),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _calcButton(String label) {
    final isEqual = label == '=';
    final isOp = ['+', '-', '×', '÷', '^', '%'].contains(label);
    final isClear = label == 'C' || label == '⌫';
    final bg = isEqual
        ? const [Color(0xff00b894), Color(0xff55efc4)]
        : isOp
            ? const [Color(0xffff8a00), Color(0xffffc371)]
            : isClear
                ? const [Color(0xffff512f), Color(0xffdd2476)]
                : scientificButton(label)
                    ? const [Color(0xff667eea), Color(0xff764ba2)]
                    : null;
    if (bg != null) {
      return InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => _tap(label),
        child: Container(decoration: gradientDecoration(bg, radius: 20), child: Center(child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)))),
      );
    }
    return FilledButton.tonal(
      style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
      onPressed: () => _tap(label),
      child: Text(label, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
    );
  }

  bool scientificButton(String label) => ['sin', 'cos', 'tan', 'log', 'ln', '√', 'π', 'e', '!', 'asin', 'acos', 'atan', 'abs', '±'].contains(label);

  void _tap(String key) {
    setState(() {
      if (key == 'C') {
        expression = '';
        preview = '۰';
        return;
      }
      if (key == '⌫') {
        if (expression.isNotEmpty) expression = expression.substring(0, expression.length - 1);
        _updatePreview();
        return;
      }
      if (key == '=') {
        final r = _evaluate();
        if (!r.startsWith('خطا')) {
          history.insert(0, '$expression = $r');
          expression = _normalizeEnglishNumbers(r);
          preview = faNum(r);
        } else {
          preview = r;
        }
        return;
      }
      if (key == '±') {
        expression = expression.startsWith('-') ? expression.substring(1) : '-$expression';
        _updatePreview();
        return;
      }
      if (key == '√') key = 'sqrt(';
      if (['sin', 'cos', 'tan', 'log', 'ln', 'asin', 'acos', 'atan', 'abs'].contains(key)) key = '$key(';
      expression += _normalizeEnglishNumbers(key);
      _updatePreview();
    });
  }

  String _normalizeEnglishNumbers(String s) {
    const fa = '۰۱۲۳۴۵۶۷۸۹';
    const en = '0123456789';
    for (var i = 0; i < fa.length; i++) {
      s = s.replaceAll(fa[i], en[i]);
    }
    return s;
  }

  void _updatePreview() {
    if (expression.trim().isEmpty) {
      preview = '۰';
      return;
    }
    final r = _evaluate(silent: true);
    preview = r.startsWith('خطا') ? faNum(expression) : faNum(r);
  }

  String _evaluate({bool silent = false}) {
    try {
      final value = ExpressionParser(expression, degree: degree).parse();
      if (value.isNaN || value.isInfinite) return 'خطا در محاسبه';
      return formatNumber(value);
    } catch (_) {
      return silent ? 'خطا' : 'خطا در فرمول';
    }
  }

  void _copyResult() {
    Clipboard.setData(ClipboardData(text: _normalizeEnglishNumbers(preview)));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('نتیجه کپی شد')));
  }
}

String formatNumber(double value) {
  if ((value - value.roundToDouble()).abs() < 1e-10) return value.round().toString();
  var s = value.toStringAsPrecision(12);
  if (s.contains('e')) return s;
  while (s.contains('.') && s.endsWith('0')) {
    s = s.substring(0, s.length - 1);
  }
  if (s.endsWith('.')) s = s.substring(0, s.length - 1);
  return s;
}

class ExpressionParser {
  final String source;
  final bool degree;
  int pos = 0;

  ExpressionParser(String input, {required this.degree})
      : source = input.replaceAll('×', '*').replaceAll('÷', '/').replaceAll('π', 'pi').replaceAll('٪', '%').replaceAll(' ', '');

  double parse() {
    final v = _parseExpression();
    _skip();
    if (pos < source.length) throw const FormatException('extra input');
    return v;
  }

  void _skip() {
    while (pos < source.length && source.codeUnitAt(pos) <= 32) pos++;
  }

  bool _eat(String c) {
    _skip();
    if (source.startsWith(c, pos)) {
      pos += c.length;
      return true;
    }
    return false;
  }

  double _parseExpression() {
    var x = _parseTerm();
    while (true) {
      if (_eat('+')) {
        x += _parseTerm();
      } else if (_eat('-')) {
        x -= _parseTerm();
      } else {
        return x;
      }
    }
  }

  double _parseTerm() {
    var x = _parsePower();
    while (true) {
      if (_eat('*')) {
        x *= _parsePower();
      } else if (_eat('/')) {
        x /= _parsePower();
      } else {
        return x;
      }
    }
  }

  double _parsePower() {
    var x = _parseUnary();
    if (_eat('^')) x = math.pow(x, _parsePower()).toDouble();
    return x;
  }

  double _parseUnary() {
    if (_eat('+')) return _parseUnary();
    if (_eat('-')) return -_parseUnary();
    return _parsePostfix();
  }

  double _parsePostfix() {
    var x = _parsePrimary();
    while (true) {
      if (_eat('!')) {
        x = _factorial(x);
      } else if (_eat('%')) {
        x = x / 100;
      } else {
        return x;
      }
    }
  }

  double _parsePrimary() {
    _skip();
    if (_eat('(')) {
      final x = _parseExpression();
      if (!_eat(')')) throw const FormatException('missing )');
      return x;
    }
    if (pos >= source.length) throw const FormatException('unexpected end');

    final ch = source[pos];
    if (_isDigit(ch) || ch == '.') {
      final start = pos;
      while (pos < source.length && (_isDigit(source[pos]) || source[pos] == '.')) pos++;
      return double.parse(source.substring(start, pos));
    }

    if (_isLetter(ch)) {
      final start = pos;
      while (pos < source.length && _isLetter(source[pos])) pos++;
      final name = source.substring(start, pos);
      if (name == 'pi') return math.pi;
      if (name == 'e') return math.e;
      if (!_eat('(')) throw const FormatException('function needs (');
      final arg = _parseExpression();
      if (!_eat(')')) throw const FormatException('function missing )');
      return _applyFunction(name, arg);
    }
    throw const FormatException('bad token');
  }

  bool _isDigit(String c) => c.codeUnitAt(0) >= 48 && c.codeUnitAt(0) <= 57;
  bool _isLetter(String c) {
    final code = c.codeUnitAt(0);
    return (code >= 65 && code <= 90) || (code >= 97 && code <= 122);
  }

  double _toRad(double x) => degree ? x * math.pi / 180 : x;
  double _fromRad(double x) => degree ? x * 180 / math.pi : x;

  double _applyFunction(String name, double x) {
    switch (name) {
      case 'sin':
        return math.sin(_toRad(x));
      case 'cos':
        return math.cos(_toRad(x));
      case 'tan':
        return math.tan(_toRad(x));
      case 'asin':
        return _fromRad(math.asin(x));
      case 'acos':
        return _fromRad(math.acos(x));
      case 'atan':
        return _fromRad(math.atan(x));
      case 'log':
        return math.log(x) / math.ln10;
      case 'ln':
        return math.log(x);
      case 'sqrt':
        return math.sqrt(x);
      case 'abs':
        return x.abs();
      default:
        throw const FormatException('unknown function');
    }
  }

  double _factorial(double x) {
    final n = x.round();
    if ((x - n).abs() > 1e-10 || n < 0 || n > 170) throw const FormatException('bad factorial');
    var r = 1.0;
    for (var i = 2; i <= n; i++) r *= i;
    return r;
  }
}

// ------------------------- Simple tools -------------------------
class UnitPage extends StatefulWidget {
  const UnitPage({super.key});
  @override
  State<UnitPage> createState() => _UnitPageState();
}

class _UnitPageState extends State<UnitPage> {
  final input = TextEditingController();
  String type = 'متر به کیلومتر';
  String output = '';

  @override
  Widget build(BuildContext context) {
    final options = ['متر به کیلومتر', 'کیلومتر به متر', 'کیلوگرم به گرم', 'گرم به کیلوگرم', 'سانتی‌گراد به فارنهایت', 'فارنهایت به سانتی‌گراد', 'لیتر به میلی‌لیتر', 'میلی‌لیتر به لیتر'];
    return AppPage(
      title: 'تبدیل واحد',
      icon: Icons.swap_horiz_rounded,
      colors: const [Color(0xff00b894), Color(0xff55efc4)],
      child: Column(children: [
        DropdownButtonFormField<String>(value: type, items: options.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => type = v!), decoration: fieldDecoration('نوع تبدیل', icon: Icons.tune_rounded)),
        const SizedBox(height: 12),
        numField(input, 'مقدار', icon: Icons.numbers_rounded),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _convert, icon: const Icon(Icons.swap_horiz_rounded), label: const Text('تبدیل کن'))),
        resultCard('نتیجه تبدیل', output, colors: const [Color(0xff00b894), Color(0xff55efc4)]),
      ]),
    );
  }

  void _convert() {
    final x = double.tryParse(input.text.replaceAll(',', '.')) ?? 0;
    final r = switch (type) {
      'متر به کیلومتر' => x / 1000,
      'کیلومتر به متر' => x * 1000,
      'کیلوگرم به گرم' => x * 1000,
      'گرم به کیلوگرم' => x / 1000,
      'سانتی‌گراد به فارنهایت' => (x * 9 / 5) + 32,
      'فارنهایت به سانتی‌گراد' => (x - 32) * 5 / 9,
      'لیتر به میلی‌لیتر' => x * 1000,
      _ => x / 1000,
    };
    setState(() => output = faNum(formatNumber(r)));
  }
}

class PercentPage extends StatefulWidget {
  const PercentPage({super.key});
  @override
  State<PercentPage> createState() => _PercentPageState();
}

class _PercentPageState extends State<PercentPage> {
  final amount = TextEditingController();
  final percent = TextEditingController();
  String output = '';

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'درصدگیر',
      icon: Icons.percent_rounded,
      colors: const [Color(0xffff7675), Color(0xffffb88c)],
      child: Column(children: [
        numField(amount, 'عدد اصلی', icon: Icons.attach_money_rounded),
        const SizedBox(height: 12),
        numField(percent, 'درصد', icon: Icons.percent_rounded),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: FilledButton(onPressed: () => _calc('value'), child: const Text('چند درصدش؟'))),
          const SizedBox(width: 10),
          Expanded(child: FilledButton.tonal(onPressed: () => _calc('discount'), child: const Text('بعد تخفیف'))),
        ]),
        resultCard('نتیجه', output, colors: const [Color(0xffff7675), Color(0xffffb88c)]),
      ]),
    );
  }

  void _calc(String mode) {
    final a = double.tryParse(amount.text.replaceAll(',', '.')) ?? 0;
    final p = double.tryParse(percent.text.replaceAll(',', '.')) ?? 0;
    final r = mode == 'discount' ? a - (a * p / 100) : a * p / 100;
    setState(() => output = faNum(formatNumber(r)));
  }
}

class BmiPage extends StatefulWidget {
  const BmiPage({super.key});
  @override
  State<BmiPage> createState() => _BmiPageState();
}

class _BmiPageState extends State<BmiPage> {
  final weight = TextEditingController();
  final height = TextEditingController();
  String output = '';

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'BMI',
      icon: Icons.monitor_weight_rounded,
      colors: const [Color(0xff11998e), Color(0xff38ef7d)],
      child: Column(children: [
        numField(weight, 'وزن به کیلوگرم', icon: Icons.monitor_weight_rounded),
        const SizedBox(height: 12),
        numField(height, 'قد به سانتی‌متر', icon: Icons.height_rounded),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _calc, icon: const Icon(Icons.favorite_rounded), label: const Text('محاسبه'))),
        resultCard('نتیجه BMI', output, colors: const [Color(0xff11998e), Color(0xff38ef7d)]),
      ]),
    );
  }

  void _calc() {
    final w = double.tryParse(weight.text.replaceAll(',', '.')) ?? 0;
    final h = (double.tryParse(height.text.replaceAll(',', '.')) ?? 0) / 100;
    if (w <= 0 || h <= 0) {
      setState(() => output = 'مقدارها را درست وارد کن');
      return;
    }
    final bmi = w / (h * h);
    final status = bmi < 18.5 ? 'کم‌وزن' : bmi < 25 ? 'نرمال' : bmi < 30 ? 'اضافه وزن' : 'چاقی';
    setState(() => output = '${faNum(bmi.toStringAsFixed(1))} - $status');
  }
}

class AgePage extends StatefulWidget {
  const AgePage({super.key});
  @override
  State<AgePage> createState() => _AgePageState();
}

class _AgePageState extends State<AgePage> {
  JDate? birthday;
  String output = '';

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'سن‌سنج شمسی',
      icon: Icons.cake_rounded,
      colors: const [Color(0xffff8a00), Color(0xffffc371)],
      child: Column(children: [
        PersianDateField(label: 'تاریخ تولد', value: birthday, onChanged: (v) => setState(() => birthday = v), icon: Icons.cake_rounded),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _calc, icon: const Icon(Icons.calculate_rounded), label: const Text('محاسبه سن'))),
        resultCard('سن شما', output, icon: Icons.cake_rounded, colors: const [Color(0xffff8a00), Color(0xffffc371)]),
      ]),
    );
  }

  void _calc() {
    final b = birthday;
    if (b == null) {
      setState(() => output = 'اول تاریخ تولد شمسی را انتخاب کن');
      return;
    }
    final t = PersianDateUtils.today();
    var y = t.y - b.y;
    var m = t.m - b.m;
    var d = t.d - b.d;
    if (d < 0) {
      m--;
      var pm = t.m - 1;
      var py = t.y;
      if (pm < 1) {
        pm = 12;
        py--;
      }
      d += PersianDateUtils.monthLength(py, pm);
    }
    if (m < 0) {
      y--;
      m += 12;
    }
    if (y < 0) {
      output = 'تاریخ تولد نباید بعد از امروز باشد';
    } else {
      output = '${faNum(y)} سال، ${faNum(m)} ماه و ${faNum(d)} روز';
    }
    setState(() {});
  }
}

// ------------------------- Notes and Checklist -------------------------
class SavedNote {
  final String text;
  final String date;
  SavedNote(this.text, this.date);
  Map<String, dynamic> toJson() => {'text': text, 'date': date};
  static SavedNote fromJson(Map<String, dynamic> json) => SavedNote(json['text'] ?? '', json['date'] ?? '');
}

class NotesPage extends StatefulWidget {
  const NotesPage({super.key});
  @override
  State<NotesPage> createState() => _NotesPageState();
}

class _NotesPageState extends State<NotesPage> {
  final controller = TextEditingController();
  List<SavedNote> notes = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('notes_v2') ?? [];
    setState(() => notes = raw.map((e) => SavedNote.fromJson(jsonDecode(e))).toList());
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('notes_v2', notes.map((e) => jsonEncode(e.toJson())).toList());
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'یادداشت',
      icon: Icons.note_alt_rounded,
      colors: const [Color(0xffa18cd1), Color(0xfffbc2eb)],
      child: Column(children: [
        TextField(controller: controller, maxLines: 5, decoration: fieldDecoration('یادداشت جدید', hint: 'متن یادداشت را بنویس...', icon: Icons.edit_note_rounded)),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _add, icon: const Icon(Icons.save_rounded), label: const Text('ذخیره یادداشت'))),
        const SizedBox(height: 14),
        ...notes.map((note) => Container(
              width: double.infinity,
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(14),
              decoration: softDecoration(radius: 22),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [Icon(Icons.calendar_today_rounded, size: 17, color: Colors.grey.shade600), const SizedBox(width: 6), Text(note.date, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)), const Spacer(), IconButton(onPressed: () => _delete(note), icon: const Icon(Icons.delete_rounded))]),
                SelectableText(note.text, style: const TextStyle(fontSize: 15, height: 1.55)),
              ]),
            )),
      ]),
    );
  }

  void _add() {
    final text = controller.text.trim();
    if (text.isEmpty) return;
    setState(() {
      notes.insert(0, SavedNote(text, PersianDateUtils.today().longText));
      controller.clear();
    });
    _save();
  }

  void _delete(SavedNote note) {
    setState(() => notes.remove(note));
    _save();
  }
}

class ChecklistPage extends StatefulWidget {
  const ChecklistPage({super.key});
  @override
  State<ChecklistPage> createState() => _ChecklistPageState();
}

class _ChecklistPageState extends State<ChecklistPage> {
  final controller = TextEditingController();
  List<String> items = [];
  Set<String> done = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      items = prefs.getStringList('check_items') ?? [];
      done = (prefs.getStringList('check_done') ?? []).toSet();
    });
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('check_items', items);
    await prefs.setStringList('check_done', done.toList());
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'چک‌لیست',
      icon: Icons.checklist_rounded,
      colors: const [Color(0xff4facfe), Color(0xff00f2fe)],
      child: Column(children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: softDecoration(radius: 24),
          child: Row(children: [
            Expanded(child: TextField(controller: controller, decoration: const InputDecoration(hintText: 'مورد جدید...', border: InputBorder.none))),
            IconButton.filled(onPressed: _add, icon: const Icon(Icons.add_rounded)),
          ]),
        ),
        const SizedBox(height: 10),
        Align(alignment: Alignment.centerRight, child: Text('امروز: ${PersianDateUtils.today().longText}', style: TextStyle(color: Colors.grey.shade600))),
        const SizedBox(height: 12),
        ...items.map((item) => Container(
              margin: const EdgeInsets.only(bottom: 10),
              decoration: softDecoration(radius: 22),
              child: CheckboxListTile(
                value: done.contains(item),
                title: Text(item, style: TextStyle(decoration: done.contains(item) ? TextDecoration.lineThrough : null, fontWeight: FontWeight.w700)),
                secondary: IconButton(onPressed: () => _delete(item), icon: const Icon(Icons.delete_outline_rounded)),
                onChanged: (v) {
                  setState(() => v == true ? done.add(item) : done.remove(item));
                  _save();
                },
              ),
            )),
      ]),
    );
  }

  void _add() {
    final text = controller.text.trim();
    if (text.isEmpty) return;
    setState(() {
      items.insert(0, text);
      controller.clear();
    });
    _save();
  }

  void _delete(String item) {
    setState(() {
      items.remove(item);
      done.remove(item);
    });
    _save();
  }
}

// ------------------------- Password manager -------------------------
class SavedPassword {
  final String title;
  final String keyword;
  final String password;
  SavedPassword({required this.title, required this.keyword, required this.password});
  Map<String, dynamic> toJson() => {'title': title, 'keyword': keyword, 'password': password};
  static SavedPassword fromJson(Map<String, dynamic> json) => SavedPassword(title: json['title'] ?? '', keyword: json['keyword'] ?? '', password: json['password'] ?? '');
}

class PasswordPage extends StatefulWidget {
  const PasswordPage({super.key});
  @override
  State<PasswordPage> createState() => _PasswordPageState();
}

class _PasswordPageState extends State<PasswordPage> {
  final title = TextEditingController();
  final keyword = TextEditingController();
  String generated = '';
  double length = 16;
  bool showSaved = false;
  List<SavedPassword> saved = [];

  @override
  void initState() {
    super.initState();
    _load();
    _generate();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('passwords_v2') ?? [];
    setState(() => saved = raw.map((e) => SavedPassword.fromJson(jsonDecode(e))).toList());
  }

  Future<void> _saveList() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('passwords_v2', saved.map((e) => jsonEncode(e.toJson())).toList());
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'رمزساز و دفتر رمز',
      icon: Icons.password_rounded,
      colors: const [Color(0xff141e30), Color(0xff243b55)],
      child: Column(children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: gradientDecoration(const [Color(0xff141e30), Color(0xff243b55)], radius: 28),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('رمز جدید', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            SelectableText(generated, textDirection: TextDirection.ltr, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
            Slider(value: length, min: 8, max: 32, divisions: 24, label: faNum(length.round()), onChanged: (v) => setState(() => length = v)),
            Row(children: [
              Expanded(child: FilledButton.icon(onPressed: _generate, icon: const Icon(Icons.refresh_rounded), label: const Text('تولید'))),
              const SizedBox(width: 10),
              Expanded(child: FilledButton.tonal(onPressed: () => _copy(generated), child: const Text('کپی رمز'))),
            ]),
          ]),
        ),
        const SizedBox(height: 14),
        TextField(controller: title, decoration: fieldDecoration('عنوان رمز', hint: 'مثلاً اینستاگرام، جیمیل...', icon: Icons.title_rounded)),
        const SizedBox(height: 10),
        TextField(controller: keyword, decoration: fieldDecoration('کلمه کلیدی یا توضیح', hint: 'اختیاری', icon: Icons.key_rounded)),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _savePassword, icon: const Icon(Icons.lock_rounded), label: const Text('ذخیره رمز با عنوان'))),
        const SizedBox(height: 16),
        Row(children: [const Icon(Icons.security_rounded), const SizedBox(width: 8), const Text('رمزهای ذخیره‌شده', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)), const Spacer(), TextButton(onPressed: () => setState(() => showSaved = !showSaved), child: Text(showSaved ? 'مخفی کن' : 'نمایش'))]),
        ...saved.map((item) => PasswordTile(item: item, visible: showSaved, onCopy: _copy, onDelete: () => _deletePassword(item))).toList(),
      ]),
    );
  }

  void _generate() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#%&*?+-_';
    final rnd = math.Random.secure();
    setState(() => generated = List.generate(length.round(), (_) => chars[rnd.nextInt(chars.length)]).join());
  }

  void _copy(String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('کپی شد')));
  }

  void _savePassword() {
    if (title.text.trim().isEmpty || generated.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('عنوان رمز را وارد کن')));
      return;
    }
    setState(() {
      saved.insert(0, SavedPassword(title: title.text.trim(), keyword: keyword.text.trim(), password: generated));
      title.clear();
      keyword.clear();
      showSaved = false;
    });
    _saveList();
  }

  void _deletePassword(SavedPassword item) {
    setState(() => saved.remove(item));
    _saveList();
  }
}

class PasswordTile extends StatelessWidget {
  final SavedPassword item;
  final bool visible;
  final void Function(String) onCopy;
  final VoidCallback onDelete;
  const PasswordTile({super.key, required this.item, required this.visible, required this.onCopy, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: softDecoration(radius: 22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.lock_rounded),
          const SizedBox(width: 8),
          Expanded(child: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
          IconButton(onPressed: () => onCopy(item.password), icon: const Icon(Icons.copy_rounded)),
          IconButton(onPressed: onDelete, icon: const Icon(Icons.delete_rounded)),
        ]),
        if (item.keyword.isNotEmpty) Text('کلمه کلیدی: ${item.keyword}', style: TextStyle(color: Colors.grey.shade600)),
        const SizedBox(height: 6),
        SelectableText(visible ? item.password : '••••••••••••••••', textDirection: TextDirection.ltr, style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
      ]),
    );
  }
}

// ------------------------- Time tools -------------------------
class TimerPage extends StatefulWidget {
  const TimerPage({super.key});
  @override
  State<TimerPage> createState() => _TimerPageState();
}

class _TimerPageState extends State<TimerPage> {
  int seconds = 60;
  int initial = 60;
  Timer? timer;

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final progress = initial == 0 ? 0.0 : seconds / initial;
    return AppPage(
      title: 'تایمر',
      icon: Icons.timer_rounded,
      colors: const [Color(0xffff9a9e), Color(0xfffecfef)],
      child: Column(children: [
        Container(
          padding: const EdgeInsets.all(24),
          decoration: softDecoration(radius: 30),
          child: Column(children: [
            SizedBox(width: 180, height: 180, child: Stack(alignment: Alignment.center, children: [
              CircularProgressIndicator(value: progress, strokeWidth: 14, strokeCap: StrokeCap.round),
              Text(_timeText(seconds), style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
            ])),
            Slider(value: initial.toDouble(), min: 10, max: 3600, divisions: 359, label: _timeText(initial), onChanged: timer == null ? (v) => setState(() { initial = v.round(); seconds = initial; }) : null),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              FilledButton.icon(onPressed: _start, icon: const Icon(Icons.play_arrow_rounded), label: const Text('شروع')),
              const SizedBox(width: 10),
              OutlinedButton(onPressed: _reset, child: const Text('ریست')),
            ]),
          ]),
        ),
      ]),
    );
  }

  String _timeText(int sec) => '${faNum((sec ~/ 60).toString().padLeft(2, '0'))}:${faNum((sec % 60).toString().padLeft(2, '0'))}';
  void _start() {
    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (seconds <= 0) {
        timer?.cancel();
        timer = null;
      } else {
        setState(() => seconds--);
      }
    });
  }

  void _reset() {
    timer?.cancel();
    setState(() {
      timer = null;
      seconds = initial;
    });
  }
}

class StopwatchPageX extends StatefulWidget {
  const StopwatchPageX({super.key});
  @override
  State<StopwatchPageX> createState() => _StopwatchPageXState();
}

class _StopwatchPageXState extends State<StopwatchPageX> {
  final sw = Stopwatch();
  Timer? ticker;
  @override
  void dispose() {
    ticker?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final e = sw.elapsed;
    final text = '${faNum(e.inMinutes.toString().padLeft(2, '0'))}:${faNum((e.inSeconds % 60).toString().padLeft(2, '0'))}.${faNum(((e.inMilliseconds % 1000) ~/ 10).toString().padLeft(2, '0'))}';
    return AppPage(
      title: 'کرنومتر',
      icon: Icons.av_timer_rounded,
      colors: const [Color(0xff667eea), Color(0xff764ba2)],
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        decoration: softDecoration(radius: 30),
        child: Column(children: [
          const Icon(Icons.speed_rounded, size: 70, color: Color(0xff667eea)),
          const SizedBox(height: 12),
          Text(text, style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w900)),
          const SizedBox(height: 18),
          Wrap(spacing: 10, children: [
            FilledButton(onPressed: _start, child: const Text('شروع')),
            OutlinedButton(onPressed: () => sw.stop(), child: const Text('توقف')),
            OutlinedButton(onPressed: () => setState(sw.reset), child: const Text('ریست')),
          ]),
        ]),
      ),
    );
  }

  void _start() {
    sw.start();
    ticker ??= Timer.periodic(const Duration(milliseconds: 40), (_) => setState(() {}));
  }
}

class CounterPage extends StatefulWidget {
  const CounterPage({super.key});
  @override
  State<CounterPage> createState() => _CounterPageState();
}

class _CounterPageState extends State<CounterPage> {
  int value = 0;
  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'شمارنده',
      icon: Icons.add_circle_rounded,
      colors: const [Color(0xffff512f), Color(0xffdd2476)],
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        decoration: softDecoration(radius: 30),
        child: Column(children: [
          Text(faNum(value), style: const TextStyle(fontSize: 78, fontWeight: FontWeight.w900)),
          const SizedBox(height: 16),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            IconButton.filled(onPressed: () => setState(() => value++), iconSize: 34, icon: const Icon(Icons.add_rounded)),
            const SizedBox(width: 18),
            IconButton.outlined(onPressed: () => setState(() => value = value > 0 ? value - 1 : 0), iconSize: 34, icon: const Icon(Icons.remove_rounded)),
          ]),
        ]),
      ),
    );
  }
}

// ------------------------- Dice, Coin, Lottery -------------------------
class DicePage extends StatefulWidget {
  const DicePage({super.key});
  @override
  State<DicePage> createState() => _DicePageState();
}

class _DicePageState extends State<DicePage> with SingleTickerProviderStateMixin {
  late final AnimationController controller;
  int face = 1;
  bool rolling = false;
  final rnd = math.Random();

  @override
  void initState() {
    super.initState();
    controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))
      ..addListener(() {
        if (rolling && (controller.value * 100).round() % 8 == 0) {
          setState(() => face = rnd.nextInt(6) + 1);
        }
      })
      ..addStatusListener((status) {
        if (status == AnimationStatus.completed) {
          setState(() {
            rolling = false;
            face = rnd.nextInt(6) + 1;
          });
          HapticFeedback.lightImpact();
        }
      });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'تاس واقعی',
      icon: Icons.casino_rounded,
      colors: const [Color(0xfff7971e), Color(0xffffd200)],
      child: Column(children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 30),
          decoration: gradientDecoration(const [Color(0xfff7971e), Color(0xffffd200)], radius: 32),
          child: Column(children: [
            AnimatedBuilder(
              animation: controller,
              builder: (_, child) {
                final a = controller.value * math.pi * 4;
                return Transform(
                  alignment: Alignment.center,
                  transform: Matrix4.identity()
                    ..setEntry(3, 2, .001)
                    ..rotateX(a)
                    ..rotateY(a * .8)
                    ..rotateZ(a * .25),
                  child: child,
                );
              },
              child: DiceFace(face: face),
            ),
            const SizedBox(height: 18),
            Text('نتیجه: ${faNum(face)}', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
          ]),
        ),
        const SizedBox(height: 16),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: rolling ? null : _roll, icon: const Icon(Icons.casino_rounded), label: const Text('پرتاب تاس'))),
      ]),
    );
  }

  void _roll() {
    HapticFeedback.selectionClick();
    setState(() => rolling = true);
    controller.forward(from: 0);
  }
}

class DiceFace extends StatelessWidget {
  final int face;
  const DiceFace({super.key, required this.face});

  @override
  Widget build(BuildContext context) {
    final dots = _dots(face);
    return Container(
      width: 150,
      height: 150,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.24), blurRadius: 30, offset: const Offset(0, 16))],
      ),
      child: Stack(children: dots.map((a) => Align(alignment: a, child: Container(width: 22, height: 22, decoration: const BoxDecoration(color: Color(0xff182033), shape: BoxShape.circle)))).toList()),
    );
  }

  List<Alignment> _dots(int n) {
    const tl = Alignment(-.55, -.55), tr = Alignment(.55, -.55), ml = Alignment(-.55, 0), c = Alignment(0, 0), mr = Alignment(.55, 0), bl = Alignment(-.55, .55), br = Alignment(.55, .55);
    return switch (n) {
      1 => [c],
      2 => [tl, br],
      3 => [tl, c, br],
      4 => [tl, tr, bl, br],
      5 => [tl, tr, c, bl, br],
      _ => [tl, tr, ml, mr, bl, br],
    };
  }
}

class CoinPage extends StatefulWidget {
  const CoinPage({super.key});
  @override
  State<CoinPage> createState() => _CoinPageState();
}

class _CoinPageState extends State<CoinPage> with SingleTickerProviderStateMixin {
  late final AnimationController controller;
  final rnd = math.Random();
  String result = '؟';
  bool flipping = false;

  @override
  void initState() {
    super.initState();
    controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1350))
      ..addStatusListener((status) {
        if (status == AnimationStatus.completed) {
          setState(() {
            flipping = false;
            result = rnd.nextBool() ? 'شیر' : 'خط';
          });
          HapticFeedback.lightImpact();
        }
      });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'شیر یا خط',
      icon: Icons.monetization_on_rounded,
      colors: const [Color(0xfff6d365), Color(0xfffda085)],
      child: Column(children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 34, horizontal: 18),
          decoration: gradientDecoration(const [Color(0xfff6d365), Color(0xfffda085)], radius: 32),
          child: Column(children: [
            AnimatedBuilder(
              animation: controller,
              builder: (_, __) {
                final angle = controller.value * math.pi * 12;
                final showFront = math.cos(angle) >= 0;
                return Transform(
                  alignment: Alignment.center,
                  transform: Matrix4.identity()
                    ..setEntry(3, 2, .001)
                    ..rotateX(controller.value * math.pi * .35)
                    ..rotateY(angle),
                  child: CoinFace(text: showFront ? 'شیر' : 'خط'),
                );
              },
            ),
            const SizedBox(height: 18),
            Text('نتیجه: $result', style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
          ]),
        ),
        const SizedBox(height: 16),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: flipping ? null : _flip, icon: const Icon(Icons.flip_rounded), label: const Text('پرتاب سکه'))),
      ]),
    );
  }

  void _flip() {
    HapticFeedback.selectionClick();
    setState(() => flipping = true);
    controller.forward(from: 0);
  }
}

class CoinFace extends StatelessWidget {
  final String text;
  const CoinFace({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 165,
      height: 165,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const RadialGradient(colors: [Color(0xfffff7ad), Color(0xffffc371), Color(0xffd88900)]),
        border: Border.all(color: Colors.white.withOpacity(.65), width: 6),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.23), blurRadius: 32, offset: const Offset(0, 18))],
      ),
      child: Center(
        child: Container(
          width: 112,
          height: 112,
          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white.withOpacity(.58), width: 3)),
          child: Center(child: Text(text, style: const TextStyle(color: Color(0xff7a4b00), fontSize: 34, fontWeight: FontWeight.w900))),
        ),
      ),
    );
  }
}

class LotteryPage extends StatefulWidget {
  const LotteryPage({super.key});
  @override
  State<LotteryPage> createState() => _LotteryPageState();
}

class _LotteryPageState extends State<LotteryPage> {
  final nameController = TextEditingController();
  List<String> names = [];
  List<String> winners = [];
  List<String> history = [];
  int winnerCount = 1;
  String rollingName = 'آماده قرعه‌کشی';
  Timer? roulette;
  bool running = false;
  final rnd = math.Random();

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  @override
  void dispose() {
    roulette?.cancel();
    super.dispose();
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => history = prefs.getStringList('lottery_history') ?? []);
  }

  Future<void> _saveHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('lottery_history', history);
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'قرعه‌کشی حرفه‌ای',
      icon: Icons.celebration_rounded,
      colors: const [Color(0xfffa709a), Color(0xffffc371)],
      child: Column(children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: gradientDecoration(const [Color(0xfffa709a), Color(0xffffc371)], radius: 30),
          child: Column(children: [
            const Icon(Icons.emoji_events_rounded, color: Colors.white, size: 58),
            const SizedBox(height: 12),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 180),
              child: Text(rollingName, key: ValueKey(rollingName), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w900)),
            ),
            const SizedBox(height: 8),
            Text('تعداد شرکت‌کننده‌ها: ${faNum(names.length)}', style: const TextStyle(color: Colors.white70)),
          ]),
        ),
        const SizedBox(height: 14),
        TextField(controller: nameController, minLines: 1, maxLines: 4, decoration: fieldDecoration('افزودن شرکت‌کننده', hint: 'یک اسم یا چند اسم در چند خط...', icon: Icons.person_add_rounded)),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: FilledButton.icon(onPressed: _addNames, icon: const Icon(Icons.add_rounded), label: const Text('افزودن'))),
          const SizedBox(width: 10),
          Expanded(child: OutlinedButton.icon(onPressed: () => setState(() { names.clear(); winners.clear(); rollingName = 'آماده قرعه‌کشی'; }), icon: const Icon(Icons.cleaning_services_rounded), label: const Text('پاک کردن'))),
        ]),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: softDecoration(radius: 24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('تعداد برنده‌ها: ${faNum(winnerCount)}', style: const TextStyle(fontWeight: FontWeight.w900)),
            Slider(value: winnerCount.toDouble().clamp(1.0, math.max(1, names.length).toDouble()).toDouble(), min: 1, max: math.max(1, names.length).toDouble(), divisions: math.max(1, names.length - 1).toInt(), onChanged: (v) => setState(() => winnerCount = v.round())),
            Wrap(spacing: 8, runSpacing: 8, children: names.map((n) => Chip(label: Text(n), deleteIcon: const Icon(Icons.close_rounded), onDeleted: () => setState(() { names.remove(n); winnerCount = winnerCount.clamp(1, math.max(1, names.length)).toInt(); }))).toList()),
          ]),
        ),
        const SizedBox(height: 14),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: running ? null : _startLottery, icon: const Icon(Icons.casino_rounded), label: const Text('شروع قرعه‌کشی'))),
        if (winners.isNotEmpty) ...[
          resultCard('برنده‌ها', winners.map((e) => '🏆 $e').join('\n'), icon: Icons.emoji_events_rounded, colors: const [Color(0xff00b894), Color(0xff55efc4)]),
          const SizedBox(height: 8),
          Row(children: [Expanded(child: OutlinedButton.icon(onPressed: () => Clipboard.setData(ClipboardData(text: winners.join('\n'))), icon: const Icon(Icons.copy_rounded), label: const Text('کپی نتیجه'))), const SizedBox(width: 10), Expanded(child: OutlinedButton.icon(onPressed: _storeResult, icon: const Icon(Icons.save_rounded), label: const Text('ذخیره')))]),
        ],
        if (history.isNotEmpty) ...[
          const SizedBox(height: 18),
          Align(alignment: Alignment.centerRight, child: Text('نتایج ذخیره‌شده', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17))),
          ...history.map((h) => Container(width: double.infinity, margin: const EdgeInsets.only(top: 8), padding: const EdgeInsets.all(12), decoration: softDecoration(radius: 18), child: SelectableText(h))).toList(),
        ],
      ]),
    );
  }

  void _addNames() {
    final entered = nameController.text.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    if (entered.isEmpty) return;
    setState(() {
      names.addAll(entered.where((e) => !names.contains(e)));
      winnerCount = winnerCount.clamp(1, math.max(1, names.length)).toInt();
      nameController.clear();
    });
  }

  void _startLottery() {
    if (names.length < winnerCount || names.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعداد شرکت‌کننده‌ها کافی نیست')));
      return;
    }
    setState(() {
      running = true;
      winners.clear();
    });
    var ticks = 0;
    roulette?.cancel();
    roulette = Timer.periodic(const Duration(milliseconds: 75), (timer) {
      ticks++;
      setState(() => rollingName = names[rnd.nextInt(names.length)]);
      if (ticks > 34) {
        timer.cancel();
        final shuffled = [...names]..shuffle(rnd);
        setState(() {
          winners = shuffled.take(winnerCount).toList();
          rollingName = winners.first;
          running = false;
        });
        HapticFeedback.mediumImpact();
      }
    });
  }

  void _storeResult() {
    if (winners.isEmpty) return;
    final text = '${PersianDateUtils.today().longText}: ${winners.join('، ')}';
    setState(() => history.insert(0, text));
    _saveHistory();
  }
}

// ------------------------- Device / coming soon -------------------------
class DeviceInfoPage extends StatelessWidget {
  const DeviceInfoPage({super.key});
  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'اطلاعات دستگاه',
      icon: Icons.phone_android_rounded,
      colors: const [Color(0xff36d1dc), Color(0xff5b86e5)],
      child: Column(children: [
        _infoTile(Icons.android_rounded, 'سیستم عامل', 'Android / Flutter'),
        _infoTile(Icons.language_rounded, 'زبان و تاریخ', 'فارسی، راست‌چین، تاریخ شمسی'),
        _infoTile(Icons.storage_rounded, 'ذخیره‌سازی', 'یادداشت، چک‌لیست، رمزها و قرعه‌کشی روی گوشی ذخیره می‌شوند'),
        _infoTile(Icons.verified_rounded, 'نسخه برنامه', 'ابزارینو ${faNum('1.1.0')}'),
      ]),
    );
  }

  Widget _infoTile(IconData icon, String title, String subtitle) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: softDecoration(radius: 22),
      child: Row(children: [Container(padding: const EdgeInsets.all(11), decoration: gradientDecoration(const [Color(0xff36d1dc), Color(0xff5b86e5)], radius: 16), child: Icon(icon, color: Colors.white)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900)), Text(subtitle, style: TextStyle(color: Colors.grey.shade600, height: 1.4))]))]),
    );
  }
}

class ComingSoonPage extends StatelessWidget {
  final String title;
  const ComingSoonPage({super.key, required this.title});
  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: title,
      icon: Icons.build_circle_rounded,
      colors: const [Color(0xff30cfd0), Color(0xff330867)],
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        decoration: softDecoration(radius: 30),
        child: const Text('این بخش در نسخه‌های بعد با دسترسی‌های لازم گوشی و پکیج‌های اختصاصی کامل می‌شود. نسخه فعلی روی ابزارهای سریع، آفلاین، شمسی و کاربردی تمرکز دارد.', style: TextStyle(fontSize: 16, height: 1.8)),
      ),
    );
  }
}
