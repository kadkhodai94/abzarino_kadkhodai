import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:io' show Platform;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:local_auth/local_auth.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

void main() => runApp(const AbzarinoApp());

class AbzarinoApp extends StatelessWidget {
  const AbzarinoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ابزارینو',
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: const Color(0xfff7f8ff),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xff6d5dfc),
          brightness: Brightness.light,
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 0,
          backgroundColor: Colors.transparent,
          foregroundColor: Color(0xff182033),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class ToolItem {
  final String title;
  final String subtitle;
  final String group;
  final IconData icon;
  final List<Color> colors;
  final WidgetBuilder builder;
  final bool featured;

  const ToolItem({
    required this.title,
    required this.subtitle,
    required this.group,
    required this.icon,
    required this.colors,
    required this.builder,
    this.featured = false,
  });
}

final List<ToolItem> tools = [
  ToolItem(title: 'ماشین حساب', subtitle: 'معمولی و مهندسی کامل', group: 'محاسبات', icon: Icons.calculate_rounded, colors: const [Color(0xff6d5dfc), Color(0xff22d3ee)], builder: (_) => const CalculatorPage(), featured: true),
  ToolItem(title: 'تبدیل واحد', subtitle: 'طول، وزن، دما و حجم', group: 'محاسبات', icon: Icons.swap_horiz_rounded, colors: const [Color(0xff00b894), Color(0xff55efc4)], builder: (_) => const UnitPage()),
  ToolItem(title: 'درصدگیر', subtitle: 'درصد، تخفیف و افزایش', group: 'محاسبات', icon: Icons.percent_rounded, colors: const [Color(0xffff7675), Color(0xffffb88c)], builder: (_) => const PercentPage()),
  ToolItem(title: 'سن‌سنج شمسی', subtitle: 'تقویم جلالی و محاسبه دقیق', group: 'محاسبات', icon: Icons.cake_rounded, colors: const [Color(0xffff8a00), Color(0xffffc371)], builder: (_) => const AgePage(), featured: true),
  ToolItem(title: 'BMI', subtitle: 'شاخص توده بدن', group: 'سلامت', icon: Icons.monitor_weight_rounded, colors: const [Color(0xff11998e), Color(0xff38ef7d)], builder: (_) => const BmiPage()),
  ToolItem(title: 'یادداشت', subtitle: 'تاریخ شمسی و ذخیره آفلاین', group: 'نوشتار', icon: Icons.note_alt_rounded, colors: const [Color(0xffa18cd1), Color(0xfffbc2eb)], builder: (_) => const NotesPage(), featured: true),
  ToolItem(title: 'چک‌لیست', subtitle: 'کارهای روزانه و خرید', group: 'نوشتار', icon: Icons.checklist_rounded, colors: const [Color(0xff4facfe), Color(0xff00f2fe)], builder: (_) => const ChecklistPage()),
  ToolItem(title: 'رمزساز', subtitle: 'ذخیره رمز با عنوان و کلمه کلیدی', group: 'امنیت', icon: Icons.password_rounded, colors: const [Color(0xff141e30), Color(0xff243b55)], builder: (_) => const PasswordPage(), featured: true),
  ToolItem(title: 'تایمر', subtitle: 'شمارش معکوس روان', group: 'زمان', icon: Icons.timer_rounded, colors: const [Color(0xffff9a9e), Color(0xfffecfef)], builder: (_) => const TimerPage()),
  ToolItem(title: 'کرنومتر', subtitle: 'زمان‌سنج دقیق', group: 'زمان', icon: Icons.av_timer_rounded, colors: const [Color(0xff667eea), Color(0xff764ba2)], builder: (_) => const StopwatchPageX()),
  ToolItem(title: 'شمارنده', subtitle: 'شمارش سریع دستی', group: 'زمان', icon: Icons.add_circle_rounded, colors: const [Color(0xffff512f), Color(0xffdd2476)], builder: (_) => const CounterPage()),
  ToolItem(title: 'شیر یا خط', subtitle: 'سکه متحرک و پرتاب واقعی‌تر', group: 'سرگرمی', icon: Icons.monetization_on_rounded, colors: const [Color(0xfff6d365), Color(0xfffda085)], builder: (_) => const CoinPage(), featured: true),
  ToolItem(title: 'قرعه‌کشی', subtitle: 'رولت، چند برنده، ذخیره نتیجه', group: 'سرگرمی', icon: Icons.celebration_rounded, colors: const [Color(0xfffa709a), Color(0xffffc371)], builder: (_) => const LotteryPage(), featured: true),
  ToolItem(title: 'اطلاعات دستگاه', subtitle: 'اطلاعات پایه برنامه و گوشی', group: 'گوشی', icon: Icons.phone_android_rounded, colors: const [Color(0xff36d1dc), Color(0xff5b86e5)], builder: (_) => const DeviceInfoPage()),
  ToolItem(title: 'ابزارهای فایل', subtitle: 'PDF، QR، OCR و تصویر', group: 'فایل', icon: Icons.folder_copy_rounded, colors: const [Color(0xff30cfd0), Color(0xff330867)], builder: (_) => const ComingSoonPage(title: 'ابزارهای فایل')),
  ToolItem(title: 'چراغ قوه و قطب‌نما', subtitle: 'نسخه سخت‌افزاری آینده', group: 'گوشی', icon: Icons.flashlight_on_rounded, colors: const [Color(0xffffafbd), Color(0xffffc3a0)], builder: (_) => const ComingSoonPage(title: 'چراغ قوه و قطب‌نما')),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String query = '';
  List<String> recent = [];

  @override
  void initState() {
    super.initState();
    _loadRecent();
  }

  Future<void> _loadRecent() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => recent = prefs.getStringList('recent_tools') ?? []);
  }

  Future<void> _open(ToolItem tool) async {
    final prefs = await SharedPreferences.getInstance();
    final next = [tool.title, ...recent.where((e) => e != tool.title)].take(6).toList();
    await prefs.setStringList('recent_tools', next);
    if (mounted) setState(() => recent = next);
    if (!mounted) return;
    Navigator.push(context, MaterialPageRoute(builder: tool.builder));
  }

  @override
  Widget build(BuildContext context) {
    final filtered = tools.where((t) => t.title.contains(query) || t.subtitle.contains(query) || t.group.contains(query)).toList();
    final groups = <String, List<ToolItem>>{};
    for (final item in filtered) {
      groups.putIfAbsent(item.group, () => []).add(item);
    }
    final recentTools = <ToolItem>[];
    for (final title in recent) {
      final match = tools.where((t) => t.title == title);
      if (match.isNotEmpty) recentTools.add(match.first);
    }
    final featured = tools.where((t) => t.featured).toList();

    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(22),
                      decoration: gradientDecoration(const [Color(0xff6d5dfc), Color(0xffff6b9d)], radius: 32),
                      child: Stack(
                        children: [
                          Positioned(left: -20, top: -20, child: _glowCircle(110, Colors.white.withOpacity(.12))),
                          Positioned(right: -18, bottom: -25, child: _glowCircle(95, Colors.white.withOpacity(.10))),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(color: Colors.white.withOpacity(.20), borderRadius: BorderRadius.circular(20)),
                                    child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 32),
                                  ),
                                  const SizedBox(width: 12),
                                  const Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text('ابزارینو', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900)),
                                        SizedBox(height: 3),
                                        Text('جعبه ابزار کامل، شاد و حرفه‌ای گوشی', style: TextStyle(color: Colors.white70, fontSize: 13)),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 18),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
                                child: TextField(
                                  onChanged: (value) => setState(() => query = value.trim()),
                                  decoration: const InputDecoration(
                                    icon: Icon(Icons.search_rounded),
                                    hintText: 'جستجوی ابزار مورد نیاز...',
                                    border: InputBorder.none,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        _miniStat('${tools.length}', 'ابزار'),
                        const SizedBox(width: 10),
                        _miniStat('شمسی', 'تقویم'),
                        const SizedBox(width: 10),
                        _miniStat('1.3.6', 'نسخه'),
                      ],
                    ),
                    if (recentTools.isNotEmpty) ...[
                      const SizedBox(height: 20),
                      _sectionTitle('آخرین ابزارهای استفاده‌شده', Icons.history_rounded),
                      const SizedBox(height: 10),
                      SizedBox(
                        height: 132,
                        child: ListView.separated(
                          clipBehavior: Clip.none,
                          padding: const EdgeInsets.only(bottom: 18),
                          scrollDirection: Axis.horizontal,
                          itemCount: recentTools.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 12),
                          itemBuilder: (_, i) => RecentToolCard(tool: recentTools[i], onTap: () => _open(recentTools[i])),
                        ),
                      ),
                    ],
                    const SizedBox(height: 20),
                    _sectionTitle('ابزارهای پرکاربرد', Icons.local_fire_department_rounded),
                    const SizedBox(height: 10),
                    SizedBox(
                      height: 204,
                      child: ListView.separated(
                        clipBehavior: Clip.none,
                        padding: const EdgeInsets.only(bottom: 22),
                        scrollDirection: Axis.horizontal,
                        itemCount: featured.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 14),
                        itemBuilder: (_, i) => FeaturedToolCard(tool: featured[i], onTap: () => _open(featured[i])),
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            ),
            ...groups.entries.map((entry) {
              return SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _sectionTitle(entry.key, Icons.grid_view_rounded),
                      const SizedBox(height: 10),
                      SizedBox(
                        height: 206,
                        child: ListView.separated(
                          clipBehavior: Clip.none,
                          padding: const EdgeInsets.only(bottom: 22),
                          scrollDirection: Axis.horizontal,
                          itemCount: entry.value.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 14),
                          itemBuilder: (_, i) => ToolCard(tool: entry.value[i], onTap: () => _open(entry.value[i])),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
            const SliverToBoxAdapter(child: SizedBox(height: 24)),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String title, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.86),
        borderRadius: BorderRadius.circular(22),
        boxShadow: [BoxShadow(color: const Color(0xff6d5dfc).withOpacity(.08), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: gradientDecoration(const [Color(0xff6d5dfc), Color(0xff22d3ee)], radius: 14),
            child: Icon(icon, color: Colors.white, size: 18),
          ),
          const SizedBox(width: 8),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: Color(0xff182033))),
        ],
      ),
    );
  }

  Widget _miniStat(String value, String label) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: softDecoration(radius: 22),
        child: Column(
          children: [
            Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: Color(0xff182033))),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}

class FeaturedToolCard extends StatelessWidget {
  final ToolItem tool;
  final VoidCallback onTap;
  const FeaturedToolCard({super.key, required this.tool, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 250,
      child: InkWell(
        borderRadius: BorderRadius.circular(34),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(19),
          decoration: premiumCardDecoration(tool.colors, radius: 34),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned(left: -34, top: -28, child: _glowCircle(112, Colors.white.withOpacity(.14))),
              Positioned(right: -26, bottom: -30, child: _glowCircle(88, Colors.black.withOpacity(.07))),
              Positioned(left: 8, top: 8, child: _premiumIcon(tool.icon, tool.colors, size: 68, iconSize: 38)),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Spacer(),
                  Text(tool.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900, shadows: [Shadow(color: Color(0x33000000), blurRadius: 8, offset: Offset(0, 2))])),
                  const SizedBox(height: 7),
                  Text(tool.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, height: 1.35, fontWeight: FontWeight.w700, fontSize: 13)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class RecentToolCard extends StatelessWidget {
  final ToolItem tool;
  final VoidCallback onTap;
  const RecentToolCard({super.key, required this.tool, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 210,
      child: InkWell(
        borderRadius: BorderRadius.circular(30),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(15),
          decoration: premiumCardDecoration(tool.colors, radius: 30),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned(left: -30, top: -26, child: _glowCircle(86, Colors.white.withOpacity(.13))),
              Row(
                children: [
                  _premiumIcon(tool.icon, tool.colors, size: 58, iconSize: 32),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(tool.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, color: Colors.white, fontSize: 15.5)),
                        const SizedBox(height: 5),
                        Text(tool.group, style: const TextStyle(fontSize: 12, color: Colors.white, fontWeight: FontWeight.w700)),
                      ],
                    ),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ToolCard extends StatelessWidget {
  final ToolItem tool;
  final VoidCallback onTap;
  const ToolCard({super.key, required this.tool, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 218,
      child: InkWell(
        borderRadius: BorderRadius.circular(34),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: premiumCardDecoration(tool.colors, radius: 34),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned(left: -34, top: -32, child: _glowCircle(104, Colors.white.withOpacity(.16))),
              Positioned(right: -24, bottom: -26, child: _glowCircle(78, Colors.black.withOpacity(.07))),
              Positioned(left: 0, top: 0, child: _premiumIcon(tool.icon, tool.colors, size: 66, iconSize: 37)),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Spacer(),
                  Text(
                    tool.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: Colors.white, shadows: [Shadow(color: Color(0x33000000), blurRadius: 8, offset: Offset(0, 2))]),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    tool.subtitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontSize: 12.5, height: 1.35, fontWeight: FontWeight.w700),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AppPage extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<Color> colors;
  final Widget child;
  final EdgeInsets padding;

  const AppPage({
    super.key,
    required this.title,
    required this.icon,
    required this.colors,
    required this.child,
    this.padding = const EdgeInsets.all(18),
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                children: [
                  IconButton.filledTonal(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: gradientDecoration(colors, radius: 24),
                      child: Row(
                        children: [
                          Icon(icon, color: Colors.white),
                          const SizedBox(width: 10),
                          Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900))),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(child: SingleChildScrollView(padding: padding, child: child)),
          ],
        ),
      ),
    );
  }
}

BoxDecoration gradientDecoration(List<Color> colors, {double radius = 24}) {
  return BoxDecoration(
    gradient: LinearGradient(colors: colors, begin: Alignment.topRight, end: Alignment.bottomLeft),
    borderRadius: BorderRadius.circular(radius),
    boxShadow: [
      BoxShadow(color: colors.last.withOpacity(.20), blurRadius: 22, offset: const Offset(0, 12)),
    ],
  );
}

BoxDecoration premiumCardDecoration(List<Color> colors, {double radius = 32}) {
  return BoxDecoration(
    borderRadius: BorderRadius.circular(radius),
    gradient: LinearGradient(colors: colors, begin: Alignment.topRight, end: Alignment.bottomLeft),
    boxShadow: [
      BoxShadow(color: colors.last.withOpacity(.25), blurRadius: 30, offset: const Offset(0, 18)),
      BoxShadow(color: Colors.black.withOpacity(.045), blurRadius: 16, offset: const Offset(0, 8)),
    ],
  );
}

Widget _premiumIcon(IconData icon, List<Color> colors, {double size = 64, double iconSize = 36}) {
  return SizedBox(
    width: size,
    height: size,
    child: Stack(
      clipBehavior: Clip.none,
      children: [
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(size * .34),
              gradient: LinearGradient(colors: [Colors.white.withOpacity(.34), Colors.white.withOpacity(.12)], begin: Alignment.topLeft, end: Alignment.bottomRight),
              boxShadow: [
                BoxShadow(color: Colors.black.withOpacity(.10), blurRadius: 14, offset: const Offset(0, 8)),
                BoxShadow(color: Colors.white.withOpacity(.20), blurRadius: 10, offset: const Offset(-4, -4)),
              ],
            ),
          ),
        ),
        Positioned.fill(
          child: Center(child: Icon(icon, color: Colors.white, size: iconSize)),
        ),
        Positioned(
          right: -2,
          top: -2,
          child: Container(width: size * .22, height: size * .22, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(.30))),
        ),
      ],
    ),
  );
}

BoxDecoration softDecoration({double radius = 24}) {
  return BoxDecoration(
    gradient: const LinearGradient(
      colors: [Color(0xffffffff), Color(0xfff8f6ff)],
      begin: Alignment.topRight,
      end: Alignment.bottomLeft,
    ),
    borderRadius: BorderRadius.circular(radius),
    boxShadow: [
      BoxShadow(color: const Color(0xff6d5dfc).withOpacity(.09), blurRadius: 26, offset: const Offset(0, 14)),
      BoxShadow(color: Colors.black.withOpacity(.035), blurRadius: 14, offset: const Offset(0, 7)),
    ],
  );
}

Widget _glowCircle(double size, Color color) {
  return Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, color: color));
}

InputDecoration fieldDecoration(String label, {String? hint, IconData? icon}) {
  return InputDecoration(
    labelText: label,
    hintText: hint,
    prefixIcon: icon == null ? null : Icon(icon),
    filled: true,
    fillColor: Colors.white,
    contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 17),
    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide(color: Colors.white.withOpacity(.95), width: 1.4)),
    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: const BorderSide(color: Color(0xff6d5dfc), width: 1.6)),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide.none),
  );
}

TextField numField(TextEditingController controller, String label, {IconData? icon}) {
  return TextField(
    controller: controller,
    keyboardType: const TextInputType.numberWithOptions(decimal: true),
    decoration: fieldDecoration(label, icon: icon),
  );
}

Widget resultCard(String title, String value, {IconData icon = Icons.done_all_rounded, List<Color> colors = const [Color(0xff6d5dfc), Color(0xff22d3ee)]}) {
  if (value.trim().isEmpty) return const SizedBox.shrink();
  return Container(
    width: double.infinity,
    margin: const EdgeInsets.only(top: 14),
    padding: const EdgeInsets.all(18),
    decoration: gradientDecoration(colors, radius: 24),
    child: Row(
      children: [
        Icon(icon, color: Colors.white),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 4),
            SelectableText(value, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
          ]),
        ),
      ],
    ),
  );
}

String faNum(Object value) {
  const en = '0123456789';
  const fa = '۰۱۲۳۴۵۶۷۸۹';
  var s = value.toString();
  for (var i = 0; i < en.length; i++) {
    s = s.replaceAll(en[i], fa[i]);
  }
  return s;
}

// ------------------------- Persian / Jalali date -------------------------
class JDate {
  final int y;
  final int m;
  final int d;
  const JDate(this.y, this.m, this.d);

  String get monthName => PersianDateUtils.monthNames[m - 1];
  String get formatted => '${faNum(y)}/${faNum(m.toString().padLeft(2, '0'))}/${faNum(d.toString().padLeft(2, '0'))}';
  String get longText => '${faNum(d)} $monthName ${faNum(y)}';

  Map<String, dynamic> toJson() => {'y': y, 'm': m, 'd': d};
  static JDate fromJson(Map<String, dynamic> json) => JDate(json['y'] as int, json['m'] as int, json['d'] as int);
}

class PersianDateUtils {
  static const monthNames = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
  static const weekDays = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];

  static JDate today() {
    final now = DateTime.now();
    return gregorianToJalali(now.year, now.month, now.day);
  }

  static bool isGregorianLeap(int year) {
    return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
  }

  static bool isJalaliLeap(int jy) {
    final a = jy > 0 ? 474 : 473;
    final b = ((jy - a) % 2820) + 474;
    return ((b + 38) * 682) % 2816 < 682;
  }

  static int monthLength(int jy, int jm) {
    if (jm <= 6) return 31;
    if (jm <= 11) return 30;
    return isJalaliLeap(jy) ? 30 : 29;
  }

  static JDate gregorianToJalali(int gy, int gm, int gd) {
    final gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    final gy2 = gy - 1600;
    final gm2 = gm - 1;
    final gd2 = gd - 1;
    var gdn = 365 * gy2 + ((gy2 + 3) ~/ 4) - ((gy2 + 99) ~/ 100) + ((gy2 + 399) ~/ 400);
    gdn += gdm[gm2] + gd2;
    if (gm2 > 1 && isGregorianLeap(gy)) gdn++;

    var jdn = gdn - 79;
    final jnp = jdn ~/ 12053;
    jdn %= 12053;
    var jy = 979 + 33 * jnp + 4 * (jdn ~/ 1461);
    jdn %= 1461;
    if (jdn >= 366) {
      jy += (jdn - 1) ~/ 365;
      jdn = (jdn - 1) % 365;
    }
    var jm = 0;
    final jdm = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
    while (jm < 11 && jdn >= jdm[jm]) {
      jdn -= jdm[jm];
      jm++;
    }
    return JDate(jy, jm + 1, jdn + 1);
  }

  static DateTime jalaliToGregorian(int jy, int jm, int jd) {
    final jdm = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
    jy -= 979;
    jm -= 1;
    jd -= 1;
    var jdn = 365 * jy + (jy ~/ 33) * 8 + (((jy % 33) + 3) ~/ 4);
    for (var i = 0; i < jm; i++) {
      jdn += jdm[i];
    }
    jdn += jd;
    var gdn = jdn + 79;
    var gy = 1600 + 400 * (gdn ~/ 146097);
    gdn %= 146097;
    var leap = true;
    if (gdn >= 36525) {
      gdn--;
      gy += 100 * (gdn ~/ 36524);
      gdn %= 36524;
      if (gdn >= 365) {
        gdn++;
      } else {
        leap = false;
      }
    }
    gy += 4 * (gdn ~/ 1461);
    gdn %= 1461;
    if (gdn >= 366) {
      leap = false;
      gdn--;
      gy += gdn ~/ 365;
      gdn %= 365;
    }
    final gdMonth = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    var gm = 0;
    while (gm < 11 && gdn >= gdMonth[gm]) {
      gdn -= gdMonth[gm];
      gm++;
    }
    return DateTime(gy, gm + 1, gdn + 1);
  }

  static int firstWeekdayIndex(int jy, int jm) {
    final g = jalaliToGregorian(jy, jm, 1);
    return (g.weekday + 1) % 7; // Saturday = 0
  }
}

Future<JDate?> showPersianDatePickerDialog(BuildContext context, {JDate? initial, int minYear = 1300, int maxYear = 1505}) async {
  final today = PersianDateUtils.today();
  var selected = initial ?? today;
  var viewYear = selected.y;
  var viewMonth = selected.m;
  return showDialog<JDate>(
    context: context,
    builder: (dialogContext) {
      return StatefulBuilder(
        builder: (context, setState) {
          final days = PersianDateUtils.monthLength(viewYear, viewMonth);
          final first = PersianDateUtils.firstWeekdayIndex(viewYear, viewMonth);
          return Dialog(
            insetPadding: const EdgeInsets.all(18),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: softDecoration(radius: 28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: gradientDecoration(const [Color(0xff6d5dfc), Color(0xffff6b9d)], radius: 22),
                    child: Row(
                      children: [
                        const Icon(Icons.calendar_month_rounded, color: Colors.white),
                        const SizedBox(width: 8),
                        const Expanded(child: Text('تقویم شمسی', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18))),
                        TextButton(
                          onPressed: () => setState(() {
                            viewYear = today.y;
                            viewMonth = today.m;
                            selected = today;
                          }),
                          child: const Text('امروز', style: TextStyle(color: Colors.white)),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      IconButton.filledTonal(
                        onPressed: () => setState(() {
                          viewMonth--;
                          if (viewMonth < 1) {
                            viewMonth = 12;
                            viewYear--;
                          }
                        }),
                        icon: const Icon(Icons.chevron_right_rounded),
                      ),
                      Expanded(
                        child: Center(
                          child: Text('${PersianDateUtils.monthNames[viewMonth - 1]} ${faNum(viewYear)}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                        ),
                      ),
                      IconButton.filledTonal(
                        onPressed: () => setState(() {
                          viewMonth++;
                          if (viewMonth > 12) {
                            viewMonth = 1;
                            viewYear++;
                          }
                        }),
                        icon: const Icon(Icons.chevron_left_rounded),
                      ),
                    ],
                  ),
                  Row(
                    children: PersianDateUtils.weekDays.map((e) => Expanded(child: Center(child: Text(e, style: TextStyle(fontWeight: FontWeight.w900, color: Colors.grey.shade600))))).toList(),
                  ),
                  const SizedBox(height: 6),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7, mainAxisSpacing: 6, crossAxisSpacing: 6),
                    itemCount: first + days,
                    itemBuilder: (_, index) {
                      if (index < first) return const SizedBox.shrink();
                      final day = index - first + 1;
                      final active = selected.y == viewYear && selected.m == viewMonth && selected.d == day;
                      return InkWell(
                        borderRadius: BorderRadius.circular(14),
                        onTap: () => setState(() => selected = JDate(viewYear, viewMonth, day)),
                        child: Container(
                          decoration: active ? gradientDecoration(const [Color(0xff6d5dfc), Color(0xff22d3ee)], radius: 14) : BoxDecoration(color: const Color(0xfff3f4ff), borderRadius: BorderRadius.circular(14)),
                          child: Center(child: Text(faNum(day), style: TextStyle(fontWeight: FontWeight.w900, color: active ? Colors.white : const Color(0xff182033)))),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('انصراف'))),
                      const SizedBox(width: 10),
                      Expanded(child: FilledButton(onPressed: () => Navigator.pop(dialogContext, selected), child: const Text('تایید'))),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}



Future<int?> showPersianPartPicker(
  BuildContext context, {
  required String title,
  required int initial,
  required int min,
  required int max,
  List<String>? labels,
}) {
  final safeInitial = initial.clamp(min, max).toInt();
  final controller = FixedExtentScrollController(initialItem: safeInitial - min);
  int selected = safeInitial;
  return showModalBottomSheet<int>(
    context: context,
    backgroundColor: Colors.transparent,
    isScrollControlled: true,
    builder: (sheetContext) {
      return StatefulBuilder(
        builder: (context, setModalState) {
          return Container(
            margin: const EdgeInsets.all(14),
            padding: const EdgeInsets.all(16),
            decoration: softDecoration(radius: 34),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: gradientDecoration(const [Color(0xff6d5dfc), Color(0xffff6b9d)], radius: 24),
                  child: Row(children: [
                    const Icon(Icons.tune_rounded, color: Colors.white),
                    const SizedBox(width: 10),
                    Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18))),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                      decoration: BoxDecoration(color: Colors.white.withOpacity(.18), borderRadius: BorderRadius.circular(14)),
                      child: Text(labels == null ? faNum(selected) : labels[selected - min], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                    ),
                  ]),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  height: 232,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        height: 56,
                        margin: const EdgeInsets.symmetric(horizontal: 18),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(colors: [Color(0xff6d5dfc), Color(0xff22d3ee)]),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [BoxShadow(color: const Color(0xff6d5dfc).withOpacity(.24), blurRadius: 20, offset: const Offset(0, 10))],
                        ),
                      ),
                      ListWheelScrollView.useDelegate(
                        controller: controller,
                        itemExtent: 56,
                        diameterRatio: 1.45,
                        perspective: .002,
                        physics: const FixedExtentScrollPhysics(),
                        onSelectedItemChanged: (i) => setModalState(() => selected = min + i),
                        childDelegate: ListWheelChildBuilderDelegate(
                          childCount: max - min + 1,
                          builder: (_, i) {
                            final value = min + i;
                            final active = value == selected;
                            final text = labels == null ? faNum(value) : labels[value - min];
                            return Center(
                              child: AnimatedDefaultTextStyle(
                                duration: const Duration(milliseconds: 160),
                                style: TextStyle(fontSize: active ? 25 : 20, fontWeight: FontWeight.w900, color: active ? Colors.white : const Color(0xff1f2937).withOpacity(.55)),
                                child: Row(mainAxisSize: MainAxisSize.min, children: [
                                  if (active) const Icon(Icons.check_circle_rounded, color: Colors.white, size: 20),
                                  if (active) const SizedBox(width: 8),
                                  Text(text),
                                ]),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Row(children: [
                  Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(sheetContext), child: const Text('انصراف'))),
                  const SizedBox(width: 10),
                  Expanded(child: FilledButton(onPressed: () => Navigator.pop(sheetContext, selected), child: const Text('تایید'))),
                ]),
              ],
            ),
          );
        },
      );
    },
  );
}

class PersianDateField extends StatelessWidget {
  final String label;
  final JDate? value;
  final ValueChanged<JDate> onChanged;
  final IconData icon;

  const PersianDateField({super.key, required this.label, required this.value, required this.onChanged, this.icon = Icons.calendar_month_rounded});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: () async {
        final picked = await showPersianDatePickerDialog(context, initial: value);
        if (picked != null) onChanged(picked);
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: softDecoration(radius: 24),
        child: Row(
          children: [
            Container(padding: const EdgeInsets.all(12), decoration: gradientDecoration(const [Color(0xff6d5dfc), Color(0xff22d3ee)], radius: 18), child: Icon(icon, color: Colors.white)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                const SizedBox(height: 4),
                Text(value?.longText ?? 'انتخاب تاریخ شمسی', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
              ]),
            ),
            const Icon(Icons.keyboard_arrow_down_rounded),
          ],
        ),
      ),
    );
  }
}

// ------------------------- Calculator -------------------------

class CalculatorPage extends StatefulWidget {
  const CalculatorPage({super.key});
  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  String expression = '';
  String preview = '۰';
  bool scientific = false;
  bool degree = true;
  final List<String> history = [];

  final List<String> normal = const ['C', '⌫', '(', ')', '۷', '۸', '۹', '÷', '۴', '۵', '۶', '×', '۱', '۲', '۳', '-', '۰', '.', '%', '+', '='];
  final List<String> functions = const ['sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'log', 'ln', '√', '^', 'π', 'e', '!', 'abs'];

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final compact = h < 760;
    return AppPage(
      title: 'ماشین حساب حرفه‌ای',
      icon: Icons.calculate_rounded,
      colors: const [Color(0xff22d3ee), Color(0xff6d5dfc)],
      padding: EdgeInsets.fromLTRB(16, compact ? 10 : 16, 16, 16),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(compact ? 12 : 16),
            decoration: gradientDecoration(const [Color(0xff101828), Color(0xff1e293b), Color(0xff312e81)], radius: 30),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Row(children: [
                _modeButton('معمولی', !scientific, () => setState(() => scientific = false)),
                const SizedBox(width: 8),
                _modeButton('مهندسی', scientific, () => setState(() => scientific = true)),
                const Spacer(),
                _modeButton(degree ? 'درجه' : 'رادیان', true, () => setState(() => degree = !degree)),
                IconButton(onPressed: _copyResult, icon: const Icon(Icons.copy_rounded, color: Colors.white)),
              ]),
              const SizedBox(height: 10),
              Container(
                height: compact ? 126 : 148,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: Colors.white.withOpacity(.08), borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.white.withOpacity(.12))),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  const Text('فرمول', style: TextStyle(color: Colors.white54, fontSize: 12, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 5),
                  Expanded(child: SingleChildScrollView(reverse: true, scrollDirection: Axis.horizontal, child: Align(alignment: Alignment.centerLeft, child: Text(expression.isEmpty ? '۰' : faNum(expression), textDirection: TextDirection.ltr, style: TextStyle(color: Colors.white70, fontSize: compact ? 18 : 20, fontWeight: FontWeight.w800))))),
                  const SizedBox(height: 5),
                  Row(children: [
                    const Text('نتیجه', style: TextStyle(color: Colors.white54, fontSize: 12, fontWeight: FontWeight.w700)),
                    const Spacer(),
                    Flexible(child: SingleChildScrollView(reverse: true, scrollDirection: Axis.horizontal, child: Text(preview, textDirection: TextDirection.ltr, style: TextStyle(color: Colors.white, fontSize: compact ? 30 : 36, fontWeight: FontWeight.w900)))),
                  ]),
                ]),
              ),
            ]),
          ),
          const SizedBox(height: 10),
          if (scientific) ...[
            SizedBox(
              height: compact ? 44 : 48,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: functions.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (_, i) => SizedBox(width: 68, child: _calcButton(functions[i], compact: true)),
              ),
            ),
            const SizedBox(height: 10),
          ],
          GridView.builder(
            itemCount: normal.length,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, mainAxisSpacing: compact ? 8 : 10, crossAxisSpacing: compact ? 8 : 10, childAspectRatio: compact ? 1.34 : 1.24),
            itemBuilder: (_, i) => _calcButton(normal[i]),
          ),
          if (history.isNotEmpty) ...[
            const SizedBox(height: 12),
            ExpansionTile(
              tilePadding: const EdgeInsets.symmetric(horizontal: 12),
              collapsedShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
              title: const Text('تاریخچه محاسبات', style: TextStyle(fontWeight: FontWeight.w900)),
              trailing: IconButton(onPressed: () => setState(() => history.clear()), icon: const Icon(Icons.delete_sweep_rounded)),
              children: history.take(8).map((h) => Container(width: double.infinity, margin: const EdgeInsets.fromLTRB(8, 0, 8, 7), padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: const Color(0xfff3f4ff), borderRadius: BorderRadius.circular(16)), child: SelectableText(faNum(h), textDirection: TextDirection.ltr, style: const TextStyle(fontWeight: FontWeight.w700)))).toList(),
            ),
          ],
        ],
      ),
    );
  }

  Widget _modeButton(String text, bool active, VoidCallback onTap) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(color: active ? Colors.white : Colors.white.withOpacity(.12), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withOpacity(.18))),
        child: Text(text, style: TextStyle(color: active ? const Color(0xff182033) : Colors.white, fontWeight: FontWeight.w900, fontSize: 12)),
      ),
    );
  }

  Widget _calcButton(String label, {bool compact = false}) {
    final isEqual = label == '=';
    final isOp = ['+', '-', '×', '÷', '^', '%'].contains(label);
    final isClear = label == 'C' || label == '⌫';
    final isFunc = scientificButton(label);
    final colors = isEqual
        ? const [Color(0xff00c9a7), Color(0xff22e6b8)]
        : isOp
            ? const [Color(0xffff8a00), Color(0xffffc371)]
            : isClear
                ? const [Color(0xffff416c), Color(0xffff4b2b)]
                : isFunc
                    ? const [Color(0xff667eea), Color(0xff764ba2)]
                    : null;
    return InkWell(
      borderRadius: BorderRadius.circular(compact ? 18 : 22),
      onTap: () => _tap(label),
      child: Container(
        decoration: colors == null ? softDecoration(radius: compact ? 18 : 22) : gradientDecoration(colors, radius: compact ? 18 : 22),
        child: Center(child: Text(label, style: TextStyle(color: colors == null ? const Color(0xff182033) : Colors.white, fontWeight: FontWeight.w900, fontSize: compact ? 14 : 20))),
      ),
    );
  }

  bool scientificButton(String label) => ['sin', 'cos', 'tan', 'log', 'ln', '√', 'π', 'e', '!', 'asin', 'acos', 'atan', 'abs'].contains(label);

  void _tap(String key) {
    setState(() {
      if (key == 'C') { expression = ''; preview = '۰'; return; }
      if (key == '⌫') { if (expression.isNotEmpty) expression = expression.substring(0, expression.length - 1); _updatePreview(); return; }
      if (key == '=') {
        final r = _evaluate();
        if (!r.startsWith('خطا')) { history.insert(0, '$expression = $r'); expression = _normalizeEnglishNumbers(r); preview = faNum(r); } else { preview = r; }
        return;
      }
      if (key == '√') key = 'sqrt(';
      if (['sin', 'cos', 'tan', 'log', 'ln', 'asin', 'acos', 'atan', 'abs'].contains(key)) key = '$key(';
      expression += _normalizeEnglishNumbers(key);
      _updatePreview();
    });
  }

  String _normalizeEnglishNumbers(String s) {
    const fa = '۰۱۲۳۴۵۶۷۸۹';
    const en = '0123456789';
    for (var i = 0; i < fa.length; i++) { s = s.replaceAll(fa[i], en[i]); }
    return s;
  }

  void _updatePreview() {
    if (expression.trim().isEmpty) { preview = '۰'; return; }
    final r = _evaluate(silent: true);
    preview = r.startsWith('خطا') ? faNum(expression) : faNum(r);
  }

  String _evaluate({bool silent = false}) {
    try {
      final value = ExpressionParser(expression, degree: degree).parse();
      if (value.isNaN || value.isInfinite) return 'خطا در محاسبه';
      return formatNumber(value);
    } catch (_) { return silent ? 'خطا' : 'خطا در فرمول'; }
  }

  void _copyResult() {
    Clipboard.setData(ClipboardData(text: _normalizeEnglishNumbers(preview)));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('نتیجه کپی شد')));
  }
}

String formatNumber(double value) {
  if ((value - value.roundToDouble()).abs() < 1e-10) return value.round().toString();
  var s = value.toStringAsPrecision(12);
  if (s.contains('e')) return s;
  while (s.contains('.') && s.endsWith('0')) {
    s = s.substring(0, s.length - 1);
  }
  if (s.endsWith('.')) s = s.substring(0, s.length - 1);
  return s;
}

class ExpressionParser {
  final String source;
  final bool degree;
  int pos = 0;

  ExpressionParser(String input, {required this.degree})
      : source = input.replaceAll('×', '*').replaceAll('÷', '/').replaceAll('π', 'pi').replaceAll('٪', '%').replaceAll(' ', '');

  double parse() {
    final v = _parseExpression();
    _skip();
    if (pos < source.length) throw const FormatException('extra input');
    return v;
  }

  void _skip() {
    while (pos < source.length && source.codeUnitAt(pos) <= 32) pos++;
  }

  bool _eat(String c) {
    _skip();
    if (source.startsWith(c, pos)) {
      pos += c.length;
      return true;
    }
    return false;
  }

  double _parseExpression() {
    var x = _parseTerm();
    while (true) {
      if (_eat('+')) {
        x += _parseTerm();
      } else if (_eat('-')) {
        x -= _parseTerm();
      } else {
        return x;
      }
    }
  }

  double _parseTerm() {
    var x = _parsePower();
    while (true) {
      if (_eat('*')) {
        x *= _parsePower();
      } else if (_eat('/')) {
        x /= _parsePower();
      } else {
        return x;
      }
    }
  }

  double _parsePower() {
    var x = _parseUnary();
    if (_eat('^')) x = math.pow(x, _parsePower()).toDouble();
    return x;
  }

  double _parseUnary() {
    if (_eat('+')) return _parseUnary();
    if (_eat('-')) return -_parseUnary();
    return _parsePostfix();
  }

  double _parsePostfix() {
    var x = _parsePrimary();
    while (true) {
      if (_eat('!')) {
        x = _factorial(x);
      } else if (_eat('%')) {
        x = x / 100;
      } else {
        return x;
      }
    }
  }

  double _parsePrimary() {
    _skip();
    if (_eat('(')) {
      final x = _parseExpression();
      if (!_eat(')')) throw const FormatException('missing )');
      return x;
    }
    if (pos >= source.length) throw const FormatException('unexpected end');

    final ch = source[pos];
    if (_isDigit(ch) || ch == '.') {
      final start = pos;
      while (pos < source.length && (_isDigit(source[pos]) || source[pos] == '.')) pos++;
      return double.parse(source.substring(start, pos));
    }

    if (_isLetter(ch)) {
      final start = pos;
      while (pos < source.length && _isLetter(source[pos])) pos++;
      final name = source.substring(start, pos);
      if (name == 'pi') return math.pi;
      if (name == 'e') return math.e;
      if (!_eat('(')) throw const FormatException('function needs (');
      final arg = _parseExpression();
      if (!_eat(')')) throw const FormatException('function missing )');
      return _applyFunction(name, arg);
    }
    throw const FormatException('bad token');
  }

  bool _isDigit(String c) => c.codeUnitAt(0) >= 48 && c.codeUnitAt(0) <= 57;
  bool _isLetter(String c) {
    final code = c.codeUnitAt(0);
    return (code >= 65 && code <= 90) || (code >= 97 && code <= 122);
  }

  double _toRad(double x) => degree ? x * math.pi / 180 : x;
  double _fromRad(double x) => degree ? x * 180 / math.pi : x;

  double _applyFunction(String name, double x) {
    switch (name) {
      case 'sin':
        return math.sin(_toRad(x));
      case 'cos':
        return math.cos(_toRad(x));
      case 'tan':
        return math.tan(_toRad(x));
      case 'asin':
        return _fromRad(math.asin(x));
      case 'acos':
        return _fromRad(math.acos(x));
      case 'atan':
        return _fromRad(math.atan(x));
      case 'log':
        return math.log(x) / math.ln10;
      case 'ln':
        return math.log(x);
      case 'sqrt':
        return math.sqrt(x);
      case 'abs':
        return x.abs();
      default:
        throw const FormatException('unknown function');
    }
  }

  double _factorial(double x) {
    final n = x.round();
    if ((x - n).abs() > 1e-10 || n < 0 || n > 170) throw const FormatException('bad factorial');
    var r = 1.0;
    for (var i = 2; i <= n; i++) r *= i;
    return r;
  }
}

// ------------------------- Simple tools -------------------------
class UnitPage extends StatefulWidget {
  const UnitPage({super.key});
  @override
  State<UnitPage> createState() => _UnitPageState();
}

class _UnitPageState extends State<UnitPage> {
  final input = TextEditingController();
  String type = 'متر به کیلومتر';
  String output = '';

  @override
  Widget build(BuildContext context) {
    final options = ['متر به کیلومتر', 'کیلومتر به متر', 'کیلوگرم به گرم', 'گرم به کیلوگرم', 'سانتی‌گراد به فارنهایت', 'فارنهایت به سانتی‌گراد', 'لیتر به میلی‌لیتر', 'میلی‌لیتر به لیتر'];
    return AppPage(
      title: 'تبدیل واحد',
      icon: Icons.swap_horiz_rounded,
      colors: const [Color(0xff00b894), Color(0xff55efc4)],
      child: Column(children: [
        DropdownButtonFormField<String>(value: type, items: options.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => type = v!), decoration: fieldDecoration('نوع تبدیل', icon: Icons.tune_rounded)),
        const SizedBox(height: 12),
        numField(input, 'مقدار', icon: Icons.numbers_rounded),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _convert, icon: const Icon(Icons.swap_horiz_rounded), label: const Text('تبدیل کن'))),
        resultCard('نتیجه تبدیل', output, colors: const [Color(0xff00b894), Color(0xff55efc4)]),
      ]),
    );
  }

  void _convert() {
    final x = double.tryParse(input.text.replaceAll(',', '.')) ?? 0;
    final r = switch (type) {
      'متر به کیلومتر' => x / 1000,
      'کیلومتر به متر' => x * 1000,
      'کیلوگرم به گرم' => x * 1000,
      'گرم به کیلوگرم' => x / 1000,
      'سانتی‌گراد به فارنهایت' => (x * 9 / 5) + 32,
      'فارنهایت به سانتی‌گراد' => (x - 32) * 5 / 9,
      'لیتر به میلی‌لیتر' => x * 1000,
      _ => x / 1000,
    };
    setState(() => output = faNum(formatNumber(r)));
  }
}


class PercentPage extends StatefulWidget {
  const PercentPage({super.key});
  @override
  State<PercentPage> createState() => _PercentPageState();
}

class _PercentPageState extends State<PercentPage> {
  final a = TextEditingController();
  final b = TextEditingController();
  int mode = 0;
  String output = '';
  final List<String> history = [];
  final List<_PercentMode> modes = const [
    _PercentMode('درصد از عدد', 'مثلاً ۲۰٪ از ۵۰۰', 'عدد اصلی', 'درصد', null, Icons.percent_rounded),
    _PercentMode('نسبت درصدی', 'مثلاً ۳۰ از ۱۵۰ چند درصد است؟', 'عدد اول', 'عدد کل', null, Icons.pie_chart_rounded),
    _PercentMode('افزایش درصدی', 'افزایش قیمت یا مقدار', 'عدد اصلی', 'درصد افزایش', null, Icons.trending_up_rounded),
    _PercentMode('تخفیف / کاهش', 'قیمت بعد از تخفیف', 'عدد اصلی', 'درصد کاهش', null, Icons.local_offer_rounded),
    _PercentMode('قبل از تخفیف', 'قیمت اولیه قبل از تخفیف', 'قیمت نهایی', 'درصد تخفیف', null, Icons.undo_rounded),
    _PercentMode('اختلاف درصدی', 'تغییر بین دو عدد', 'عدد قدیم', 'عدد جدید', null, Icons.compare_arrows_rounded),
    _PercentMode('مالیات / کارمزد', 'اضافه شدن درصد به مبلغ', 'مبلغ', 'درصد مالیات/کارمزد', null, Icons.receipt_long_rounded),
    _PercentMode('سود و زیان', 'قیمت خرید و فروش', 'قیمت خرید', 'قیمت فروش', null, Icons.show_chart_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    final current = modes[mode];
    return AppPage(
      title: 'درصدگیر حرفه‌ای',
      icon: Icons.percent_rounded,
      colors: const [Color(0xffff7675), Color(0xffffb88c)],
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: gradientDecoration(const [Color(0xffff7675), Color(0xffffb88c)], radius: 32),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('نوع محاسبه را انتخاب کن', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 20)),
            const SizedBox(height: 12),
            SizedBox(
              height: 118,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: modes.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (_, i) => _modeCard(i),
              ),
            ),
          ]),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: softDecoration(radius: 30),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(padding: const EdgeInsets.all(13), decoration: gradientDecoration(const [Color(0xffff7675), Color(0xffffb88c)], radius: 18), child: Icon(current.icon, color: Colors.white)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(current.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                const SizedBox(height: 4),
                Text(current.desc, style: TextStyle(color: Colors.grey.shade600, height: 1.45)),
              ])),
            ]),
            const SizedBox(height: 16),
            numField(a, current.firstLabel, icon: Icons.numbers_rounded),
            const SizedBox(height: 10),
            numField(b, current.secondLabel, icon: Icons.percent_rounded),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(flex: 2, child: FilledButton.icon(onPressed: _calc, icon: const Icon(Icons.calculate_rounded), label: const Text('محاسبه'))),
              const SizedBox(width: 10),
              Expanded(child: OutlinedButton.icon(onPressed: _clear, icon: const Icon(Icons.cleaning_services_rounded), label: const Text('پاک'))),
            ]),
          ]),
        ),
        if (output.isNotEmpty) ...[
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: gradientDecoration(const [Color(0xff6d5dfc), Color(0xff22d3ee)], radius: 30),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [const Icon(Icons.analytics_rounded, color: Colors.white), const SizedBox(width: 8), const Text('نتیجه محاسبه', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w800)), const Spacer(), IconButton(onPressed: _copyOutput, icon: const Icon(Icons.copy_rounded, color: Colors.white))]),
              const SizedBox(height: 8),
              SelectableText(output, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900, height: 1.6)),
            ]),
          ),
        ],
        if (history.isNotEmpty) ...[
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: softDecoration(radius: 24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('تاریخچه درصدگیری', style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              ...history.take(5).map((e) => Padding(padding: const EdgeInsets.only(top: 6), child: Text(e, style: TextStyle(color: Colors.grey.shade700, height: 1.4)))).toList(),
            ]),
          ),
        ],
      ]),
    );
  }

  Widget _modeCard(int i) {
    final active = i == mode;
    final m = modes[i];
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: () => setState(() { mode = i; output = ''; }),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 150,
        padding: const EdgeInsets.all(13),
        decoration: active
            ? BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.14), blurRadius: 18, offset: const Offset(0, 10))])
            : BoxDecoration(color: Colors.white.withOpacity(.18), borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.white.withOpacity(.35))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(m.icon, color: active ? const Color(0xffff7675) : Colors.white, size: 26),
          const Spacer(),
          Text(m.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: active ? const Color(0xff182033) : Colors.white, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text(m.desc, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: active ? Colors.grey.shade600 : Colors.white70, fontSize: 11, height: 1.3)),
        ]),
      ),
    );
  }

  double _num(TextEditingController t) => double.tryParse(t.text.replaceAll('،', '.').replaceAll(',', '.')) ?? 0;

  void _calc() {
    final x = _num(a);
    final y = _num(b);
    String text;
    switch (mode) {
      case 0:
        final r = x * y / 100;
        text = '${faNum(formatNumber(y))}٪ از ${faNum(formatNumber(x))} = ${faNum(formatNumber(r))}';
        break;
      case 1:
        text = y == 0 ? 'عدد کل نمی‌تواند صفر باشد' : '${faNum(formatNumber(x))} برابر ${faNum(formatNumber(x / y * 100))}٪ از ${faNum(formatNumber(y))} است';
        break;
      case 2:
        final r = x + x * y / 100;
        text = 'مقدار افزایش: ${faNum(formatNumber(x * y / 100))}\nمقدار نهایی: ${faNum(formatNumber(r))}';
        break;
      case 3:
        final discount = x * y / 100;
        final r = x - discount;
        text = 'مبلغ تخفیف: ${faNum(formatNumber(discount))}\nقیمت نهایی: ${faNum(formatNumber(r))}';
        break;
      case 4:
        text = y >= 100 ? 'درصد تخفیف باید کمتر از ۱۰۰ باشد' : 'قیمت قبل از تخفیف: ${faNum(formatNumber(x / (1 - y / 100)))}';
        break;
      case 5:
        text = x == 0 ? 'عدد قدیم نمی‌تواند صفر باشد' : 'تغییر درصدی: ${faNum(formatNumber((y - x) / x * 100))}٪\nاختلاف عددی: ${faNum(formatNumber(y - x))}';
        break;
      case 6:
        final fee = x * y / 100;
        text = 'مبلغ کارمزد/مالیات: ${faNum(formatNumber(fee))}\nجمع نهایی: ${faNum(formatNumber(x + fee))}';
        break;
      default:
        if (x == 0) { text = 'قیمت خرید نمی‌تواند صفر باشد'; } else { final profit = y - x; text = '${profit >= 0 ? 'سود' : 'زیان'}: ${faNum(formatNumber(profit.abs()))}\nدرصد: ${faNum(formatNumber(profit / x * 100))}٪'; }
    }
    setState(() { output = text; history.insert(0, '${modes[mode].title}: $text'); });
  }

  void _clear() { a.clear(); b.clear(); setState(() => output = ''); }
  void _copyOutput() { Clipboard.setData(ClipboardData(text: output)); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('نتیجه کپی شد'))); }
}

class _PercentMode {
  final String title;
  final String desc;
  final String firstLabel;
  final String secondLabel;
  final String? thirdLabel;
  final IconData icon;
  const _PercentMode(this.title, this.desc, this.firstLabel, this.secondLabel, this.thirdLabel, this.icon);
}

class BmiPage extends StatefulWidget {
  const BmiPage({super.key});
  @override
  State<BmiPage> createState() => _BmiPageState();
}

class _BmiPageState extends State<BmiPage> {
  final weight = TextEditingController();
  final height = TextEditingController();
  String output = '';

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'BMI',
      icon: Icons.monitor_weight_rounded,
      colors: const [Color(0xff11998e), Color(0xff38ef7d)],
      child: Column(children: [
        numField(weight, 'وزن به کیلوگرم', icon: Icons.monitor_weight_rounded),
        const SizedBox(height: 12),
        numField(height, 'قد به سانتی‌متر', icon: Icons.height_rounded),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _calc, icon: const Icon(Icons.favorite_rounded), label: const Text('محاسبه'))),
        resultCard('نتیجه BMI', output, colors: const [Color(0xff11998e), Color(0xff38ef7d)]),
      ]),
    );
  }

  void _calc() {
    final w = double.tryParse(weight.text.replaceAll(',', '.')) ?? 0;
    final h = (double.tryParse(height.text.replaceAll(',', '.')) ?? 0) / 100;
    if (w <= 0 || h <= 0) {
      setState(() => output = 'مقدارها را درست وارد کن');
      return;
    }
    final bmi = w / (h * h);
    final status = bmi < 18.5 ? 'کم‌وزن' : bmi < 25 ? 'نرمال' : bmi < 30 ? 'اضافه وزن' : 'چاقی';
    setState(() => output = '${faNum(bmi.toStringAsFixed(1))} - $status');
  }
}

class AgePage extends StatefulWidget {
  const AgePage({super.key});
  @override
  State<AgePage> createState() => _AgePageState();
}

class _AgePageState extends State<AgePage> {
  int? year;
  int? month;
  int? day;
  String output = '';

  JDate? get birthday => year == null || month == null || day == null ? null : JDate(year!, month!, day!);

  @override
  Widget build(BuildContext context) {
    final b = birthday;
    return AppPage(
      title: 'سن‌سنج شمسی',
      icon: Icons.cake_rounded,
      colors: const [Color(0xffff8a00), Color(0xffffc371)],
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: gradientDecoration(const [Color(0xffff8a00), Color(0xffffc371)], radius: 30),
          child: Row(children: [
            Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: Colors.white.withOpacity(.20), borderRadius: BorderRadius.circular(20)), child: const Icon(Icons.calendar_month_rounded, color: Colors.white, size: 32)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('تاریخ تولد شمسی', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 20)), const SizedBox(height: 4), Text(b?.longText ?? 'روز، ماه و سال را جدا انتخاب کن', style: const TextStyle(color: Colors.white70))])),
          ]),
        ),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(child: _dateBox('روز', day == null ? 'انتخاب' : faNum(day!), Icons.today_rounded, _pickDay)),
          const SizedBox(width: 10),
          Expanded(child: _dateBox('ماه', month == null ? 'انتخاب' : PersianDateUtils.monthNames[month! - 1], Icons.calendar_view_month_rounded, _pickMonth)),
          const SizedBox(width: 10),
          Expanded(child: _dateBox('سال', year == null ? 'انتخاب' : faNum(year!), Icons.event_rounded, _pickYear)),
        ]),
        const SizedBox(height: 14),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _calc, icon: const Icon(Icons.calculate_rounded), label: const Text('محاسبه سن'))),
        if (output.isNotEmpty) ...[
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: softDecoration(radius: 30),
            child: Column(children: [
              const Icon(Icons.cake_rounded, size: 54, color: Color(0xffff8a00)),
              const SizedBox(height: 10),
              const Text('سن شما', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
              const SizedBox(height: 12),
              _ageResultCards(output),
            ]),
          ),
        ],
      ]),
    );
  }

  Widget _dateBox(String label, String value, IconData icon, VoidCallback onTap) {
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 16),
        decoration: softDecoration(radius: 24),
        child: Column(children: [
          Container(padding: const EdgeInsets.all(10), decoration: gradientDecoration(const [Color(0xffff8a00), Color(0xffffc371)], radius: 16), child: Icon(icon, color: Colors.white, size: 22)),
          const SizedBox(height: 9),
          Text(label, style: TextStyle(color: Colors.grey.shade600, fontWeight: FontWeight.w700)),
          const SizedBox(height: 3),
          Text(value, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
        ]),
      ),
    );
  }

  Widget _ageResultCards(String text) {
    if (!text.contains('سال')) return Text(text, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18));
    final parts = text.split('،');
    return Row(children: List.generate(parts.length, (i) => Expanded(child: Container(
      margin: EdgeInsets.only(left: i == parts.length - 1 ? 0 : 8),
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      decoration: gradientDecoration(i == 0 ? const [Color(0xff6d5dfc), Color(0xff22d3ee)] : i == 1 ? const [Color(0xffff7675), Color(0xffffb88c)] : const [Color(0xff00b894), Color(0xff55efc4)], radius: 22),
      child: Text(parts[i].trim(), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15)),
    ))));
  }

  Future<void> _pickYear() async {
    final today = PersianDateUtils.today();
    final picked = await showPersianPartPicker(context, title: 'انتخاب سال تولد', initial: year ?? 1375, min: 1300, max: today.y);
    if (picked != null) {
      setState(() {
        year = picked;
        _clampDay();
      });
    }
  }

  Future<void> _pickMonth() async {
    final picked = await showPersianPartPicker(context, title: 'انتخاب ماه تولد', initial: month ?? 1, min: 1, max: 12, labels: PersianDateUtils.monthNames);
    if (picked != null) {
      setState(() {
        month = picked;
        _clampDay();
      });
    }
  }

  Future<void> _pickDay() async {
    final maxDay = PersianDateUtils.monthLength(year ?? PersianDateUtils.today().y, month ?? 1);
    final picked = await showPersianPartPicker(context, title: 'انتخاب روز تولد', initial: day ?? 1, min: 1, max: maxDay);
    if (picked != null) setState(() => day = picked);
  }

  void _clampDay() {
    if (day == null) return;
    final maxDay = PersianDateUtils.monthLength(year ?? PersianDateUtils.today().y, month ?? 1);
    if (day! > maxDay) day = maxDay;
  }

  void _calc() {
    final b = birthday;
    if (b == null) {
      setState(() => output = 'روز، ماه و سال تولد را کامل انتخاب کن');
      return;
    }
    final t = PersianDateUtils.today();
    var y = t.y - b.y;
    var m = t.m - b.m;
    var d = t.d - b.d;
    if (d < 0) {
      m--;
      var pm = t.m - 1;
      var py = t.y;
      if (pm < 1) { pm = 12; py--; }
      d += PersianDateUtils.monthLength(py, pm);
    }
    if (m < 0) { y--; m += 12; }
    setState(() => output = y < 0 ? 'تاریخ تولد نباید بعد از امروز باشد' : '${faNum(y)} سال، ${faNum(m)} ماه، ${faNum(d)} روز');
  }
}

// ------------------------- Notes and Checklist -------------------------
class SavedNote {
  final String text;
  final String date;
  SavedNote(this.text, this.date);
  Map<String, dynamic> toJson() => {'text': text, 'date': date};
  static SavedNote fromJson(Map<String, dynamic> json) => SavedNote(json['text'] ?? '', json['date'] ?? '');
}

class NotesPage extends StatefulWidget {
  const NotesPage({super.key});
  @override
  State<NotesPage> createState() => _NotesPageState();
}

class _NotesPageState extends State<NotesPage> {
  final controller = TextEditingController();
  List<SavedNote> notes = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('notes_v2') ?? [];
    setState(() => notes = raw.map((e) => SavedNote.fromJson(jsonDecode(e))).toList());
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('notes_v2', notes.map((e) => jsonEncode(e.toJson())).toList());
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'یادداشت',
      icon: Icons.note_alt_rounded,
      colors: const [Color(0xffa18cd1), Color(0xfffbc2eb)],
      child: Column(children: [
        TextField(controller: controller, maxLines: 5, decoration: fieldDecoration('یادداشت جدید', hint: 'متن یادداشت را بنویس...', icon: Icons.edit_note_rounded)),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _add, icon: const Icon(Icons.save_rounded), label: const Text('ذخیره یادداشت'))),
        const SizedBox(height: 14),
        ...notes.map((note) => Container(
              width: double.infinity,
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(14),
              decoration: softDecoration(radius: 22),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [Icon(Icons.calendar_today_rounded, size: 17, color: Colors.grey.shade600), const SizedBox(width: 6), Text(note.date, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)), const Spacer(), IconButton(onPressed: () => _delete(note), icon: const Icon(Icons.delete_rounded))]),
                SelectableText(note.text, style: const TextStyle(fontSize: 15, height: 1.55)),
              ]),
            )),
      ]),
    );
  }

  void _add() {
    final text = controller.text.trim();
    if (text.isEmpty) return;
    setState(() {
      notes.insert(0, SavedNote(text, PersianDateUtils.today().longText));
      controller.clear();
    });
    _save();
  }

  void _delete(SavedNote note) {
    setState(() => notes.remove(note));
    _save();
  }
}

class ChecklistPage extends StatefulWidget {
  const ChecklistPage({super.key});
  @override
  State<ChecklistPage> createState() => _ChecklistPageState();
}

class _ChecklistPageState extends State<ChecklistPage> {
  final controller = TextEditingController();
  List<String> items = [];
  Set<String> done = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      items = prefs.getStringList('check_items') ?? [];
      done = (prefs.getStringList('check_done') ?? []).toSet();
    });
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('check_items', items);
    await prefs.setStringList('check_done', done.toList());
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'چک‌لیست',
      icon: Icons.checklist_rounded,
      colors: const [Color(0xff4facfe), Color(0xff00f2fe)],
      child: Column(children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: softDecoration(radius: 24),
          child: Row(children: [
            Expanded(child: TextField(controller: controller, decoration: const InputDecoration(hintText: 'مورد جدید...', border: InputBorder.none))),
            IconButton.filled(onPressed: _add, icon: const Icon(Icons.add_rounded)),
          ]),
        ),
        const SizedBox(height: 10),
        Align(alignment: Alignment.centerRight, child: Text('امروز: ${PersianDateUtils.today().longText}', style: TextStyle(color: Colors.grey.shade600))),
        const SizedBox(height: 12),
        ...items.map((item) => Container(
              margin: const EdgeInsets.only(bottom: 10),
              decoration: softDecoration(radius: 22),
              child: CheckboxListTile(
                value: done.contains(item),
                title: Text(item, style: TextStyle(decoration: done.contains(item) ? TextDecoration.lineThrough : null, fontWeight: FontWeight.w700)),
                secondary: IconButton(onPressed: () => _delete(item), icon: const Icon(Icons.delete_outline_rounded)),
                onChanged: (v) {
                  setState(() => v == true ? done.add(item) : done.remove(item));
                  _save();
                },
              ),
            )),
      ]),
    );
  }

  void _add() {
    final text = controller.text.trim();
    if (text.isEmpty) return;
    setState(() {
      items.insert(0, text);
      controller.clear();
    });
    _save();
  }

  void _delete(String item) {
    setState(() {
      items.remove(item);
      done.remove(item);
    });
    _save();
  }
}

// ------------------------- Password manager -------------------------
class SavedPassword {
  final String title;
  final String keyword;
  final String password;
  SavedPassword({required this.title, required this.keyword, required this.password});
  Map<String, dynamic> toJson() => {'title': title, 'keyword': keyword, 'password': password};
  static SavedPassword fromJson(Map<String, dynamic> json) => SavedPassword(title: json['title'] ?? '', keyword: json['keyword'] ?? '', password: json['password'] ?? '');
}

class PasswordPage extends StatefulWidget {
  const PasswordPage({super.key});
  @override
  State<PasswordPage> createState() => _PasswordPageState();
}

class _PasswordPageState extends State<PasswordPage> {
  final title = TextEditingController();
  final keyword = TextEditingController();
  final LocalAuthentication auth = LocalAuthentication();
  String generated = '';
  double length = 16;
  List<SavedPassword> saved = [];
  final Set<SavedPassword> revealed = {};

  @override
  void initState() {
    super.initState();
    _load();
    _generate();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('passwords_v2') ?? [];
    setState(() => saved = raw.map((e) => SavedPassword.fromJson(jsonDecode(e))).toList());
  }

  Future<void> _saveList() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('passwords_v2', saved.map((e) => jsonEncode(e.toJson())).toList());
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'رمزساز و دفتر رمز امن',
      icon: Icons.password_rounded,
      colors: const [Color(0xff141e30), Color(0xff243b55)],
      child: Column(children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: gradientDecoration(const [Color(0xff141e30), Color(0xff243b55)], radius: 30),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(children: [const Icon(Icons.shield_rounded, color: Colors.white), const SizedBox(width: 8), const Text('رمز جدید', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)), const Spacer(), Text('طول: ${faNum(length.round())}', style: const TextStyle(color: Colors.white70))]),
            const SizedBox(height: 10),
            SelectableText(generated, textDirection: TextDirection.ltr, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
            Slider(value: length, min: 8, max: 32, divisions: 24, label: faNum(length.round()), onChanged: (v) => setState(() => length = v)),
            Row(children: [
              Expanded(child: FilledButton.icon(onPressed: _generate, icon: const Icon(Icons.refresh_rounded), label: const Text('تولید'))),
              const SizedBox(width: 10),
              Expanded(child: FilledButton.tonal(onPressed: () => _copy(generated), child: const Text('کپی رمز'))),
            ]),
          ]),
        ),
        const SizedBox(height: 14),
        TextField(controller: title, decoration: fieldDecoration('عنوان رمز', hint: 'مثلاً اینستاگرام، جیمیل...', icon: Icons.title_rounded)),
        const SizedBox(height: 10),
        TextField(controller: keyword, decoration: fieldDecoration('کلمه کلیدی یا توضیح', hint: 'اختیاری', icon: Icons.key_rounded)),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _savePassword, icon: const Icon(Icons.lock_rounded), label: const Text('ذخیره رمز با عنوان'))),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: softDecoration(radius: 24),
          child: Row(children: [
            Container(padding: const EdgeInsets.all(10), decoration: gradientDecoration(const [Color(0xff141e30), Color(0xff243b55)], radius: 16), child: const Icon(Icons.fingerprint_rounded, color: Colors.white)),
            const SizedBox(width: 10),
            const Expanded(child: Text('برای دیدن یا کپی رمزهای ذخیره‌شده، اثر انگشت/قفل گوشی یا رمز برنامه لازم است.', style: TextStyle(fontWeight: FontWeight.w800, height: 1.5))),
          ]),
        ),
        const SizedBox(height: 14),
        Row(children: [const Icon(Icons.security_rounded), const SizedBox(width: 8), const Text('رمزهای ذخیره‌شده', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17))]),
        const SizedBox(height: 8),
        ...saved.map((item) => PasswordTile(
              item: item,
              visible: revealed.contains(item),
              onReveal: () => _reveal(item),
              onCopy: () => _copySaved(item),
              onDelete: () => _deletePassword(item),
            )).toList(),
      ]),
    );
  }

  void _generate() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#%&*?+-_';
    final rnd = math.Random.secure();
    setState(() => generated = List.generate(length.round(), (_) => chars[rnd.nextInt(chars.length)]).join());
  }

  void _copy(String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('کپی شد')));
  }

  Future<void> _reveal(SavedPassword item) async {
    if (revealed.contains(item)) {
      setState(() => revealed.remove(item));
      return;
    }
    if (await _authGate('برای نمایش رمز، هویت خود را تایید کن')) setState(() => revealed.add(item));
  }

  Future<void> _copySaved(SavedPassword item) async {
    if (await _authGate('برای کپی کردن رمز، هویت خود را تایید کن')) _copy(item.password);
  }

  Future<bool> _authGate(String reason) async {
    try {
      final supported = await auth.isDeviceSupported();
      final canBio = await auth.canCheckBiometrics;
      if (supported || canBio) {
        final ok = await auth.authenticate(
          localizedReason: reason,
          options: const AuthenticationOptions(stickyAuth: true, biometricOnly: false),
        );
        if (ok) return true;
      }
    } catch (_) {}
    return _pinGate();
  }

  Future<bool> _pinGate() async {
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getString('abzarino_pin');
    final controller = TextEditingController();
    final titleText = stored == null ? 'ساخت رمز برنامه' : 'ورود رمز برنامه';
    final hint = stored == null ? 'یک رمز حداقل ۴ رقمی بساز' : 'رمز برنامه را وارد کن';
    final ok = await showDialog<bool>(
      context: context,
      builder: (dContext) => AlertDialog(
        title: Text(titleText),
        content: TextField(controller: controller, keyboardType: TextInputType.number, obscureText: true, decoration: InputDecoration(hintText: hint)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dContext, false), child: const Text('انصراف')),
          FilledButton(onPressed: () async {
            final value = controller.text.trim();
            if (stored == null) {
              if (value.length < 4) return;
              await prefs.setString('abzarino_pin', value);
              if (dContext.mounted) Navigator.pop(dContext, true);
            } else {
              Navigator.pop(dContext, value == stored);
            }
          }, child: const Text('تایید')),
        ],
      ),
    );
    if (ok != true && mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('احراز هویت انجام نشد')));
    return ok == true;
  }

  void _savePassword() {
    if (title.text.trim().isEmpty || generated.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('عنوان رمز را وارد کن')));
      return;
    }
    setState(() {
      saved.insert(0, SavedPassword(title: title.text.trim(), keyword: keyword.text.trim(), password: generated));
      title.clear();
      keyword.clear();
    });
    _saveList();
  }

  void _deletePassword(SavedPassword item) {
    setState(() { saved.remove(item); revealed.remove(item); });
    _saveList();
  }
}

class PasswordTile extends StatelessWidget {
  final SavedPassword item;
  final bool visible;
  final VoidCallback onReveal;
  final VoidCallback onCopy;
  final VoidCallback onDelete;
  const PasswordTile({super.key, required this.item, required this.visible, required this.onReveal, required this.onCopy, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: softDecoration(radius: 24),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(padding: const EdgeInsets.all(9), decoration: gradientDecoration(const [Color(0xff141e30), Color(0xff243b55)], radius: 15), child: const Icon(Icons.lock_rounded, color: Colors.white, size: 20)),
          const SizedBox(width: 8),
          Expanded(child: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
          IconButton(onPressed: onReveal, icon: Icon(visible ? Icons.visibility_off_rounded : Icons.visibility_rounded)),
          IconButton(onPressed: onCopy, icon: const Icon(Icons.copy_rounded)),
          IconButton(onPressed: onDelete, icon: const Icon(Icons.delete_rounded)),
        ]),
        if (item.keyword.isNotEmpty) Text('کلمه کلیدی: ${item.keyword}', style: TextStyle(color: Colors.grey.shade600)),
        const SizedBox(height: 8),
        Container(width: double.infinity, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xfff3f4ff), borderRadius: BorderRadius.circular(16)), child: SelectableText(visible ? item.password : '••••••••••••••••', textDirection: TextDirection.ltr, style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2))),
      ]),
    );
  }
}

// ------------------------- Time tools -------------------------

class TimerPage extends StatefulWidget {
  const TimerPage({super.key});
  @override
  State<TimerPage> createState() => _TimerPageState();
}

class _TimerPageState extends State<TimerPage> {
  int seconds = 60;
  int initial = 60;
  Timer? timer;
  final List<int> presets = const [5, 10, 15, 30, 45, 60];

  bool get running => timer != null;
  String get stateText => seconds <= 0 ? 'پایان یافته' : running ? 'در حال اجرا' : seconds == initial ? 'آماده شروع' : 'متوقف شده';

  @override
  void dispose() { timer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final progress = initial == 0 ? 0.0 : seconds / initial;
    return AppPage(
      title: 'تایمر حرفه‌ای',
      icon: Icons.timer_rounded,
      colors: const [Color(0xffff9a9e), Color(0xfffecfef)],
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: gradientDecoration(const [Color(0xffff9a9e), Color(0xfffad0c4), Color(0xfffecfef)], radius: 34),
          child: Column(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(color: Colors.white.withOpacity(.22), borderRadius: BorderRadius.circular(18)),
              child: Text(stateText, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: 230,
              height: 230,
              child: Stack(alignment: Alignment.center, children: [
                Container(decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(.18), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.10), blurRadius: 20, offset: const Offset(0, 12))])),
                SizedBox(width: 204, height: 204, child: CircularProgressIndicator(value: progress.clamp(0.0, 1.0).toDouble(), strokeWidth: 17, strokeCap: StrokeCap.round, backgroundColor: Colors.white.withOpacity(.36), valueColor: const AlwaysStoppedAnimation<Color>(Color(0xff6d5dfc)))),
                Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(seconds <= 0 ? Icons.notifications_active_rounded : Icons.hourglass_bottom_rounded, color: Colors.white, size: 34),
                  const SizedBox(height: 8),
                  Text(_timeText(seconds), style: const TextStyle(color: Colors.white, fontSize: 44, fontWeight: FontWeight.w900, letterSpacing: 1.4)),
                  const Text('زمان باقی‌مانده', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700)),
                ]),
              ]),
            ),
            const SizedBox(height: 16),
            Wrap(alignment: WrapAlignment.center, spacing: 8, runSpacing: 8, children: presets.map((m) => ChoiceChip(
              label: Text('${faNum(m)} دقیقه', style: const TextStyle(fontWeight: FontWeight.w800)),
              selected: initial == m * 60,
              onSelected: running ? null : (_) => setState(() { initial = m * 60; seconds = initial; }),
              selectedColor: Colors.white,
              backgroundColor: Colors.white.withOpacity(.18),
            )).toList()),
          ]),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: softDecoration(radius: 28),
          child: Column(children: [
            Row(children: [
              const Icon(Icons.tune_rounded, color: Color(0xff6d5dfc)),
              const SizedBox(width: 8),
              Text('تنظیم دستی: ${_timeText(initial)}', style: const TextStyle(fontWeight: FontWeight.w900)),
            ]),
            Slider(value: initial.toDouble(), min: 10, max: 3600, divisions: 359, label: _timeText(initial), onChanged: running ? null : (v) => setState(() { initial = v.round(); seconds = initial; })),
            Row(children: [
              Expanded(flex: 2, child: FilledButton.icon(onPressed: _startPause, icon: Icon(running ? Icons.pause_rounded : Icons.play_arrow_rounded), label: Text(running ? 'توقف' : 'شروع / ادامه'))),
              const SizedBox(width: 10),
              Expanded(child: OutlinedButton.icon(onPressed: _reset, icon: const Icon(Icons.replay_rounded), label: const Text('ریست'))),
            ]),
          ]),
        ),
      ]),
    );
  }

  String _timeText(int sec) => '${faNum((sec ~/ 60).toString().padLeft(2, '0'))}:${faNum((sec % 60).toString().padLeft(2, '0'))}';

  void _startPause() {
    if (timer != null) { timer?.cancel(); setState(() => timer = null); return; }
    if (seconds <= 0) seconds = initial;
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (seconds <= 1) { timer?.cancel(); timer = null; seconds = 0; HapticFeedback.mediumImpact(); setState(() {}); } else { setState(() => seconds--); }
    });
    setState(() {});
  }

  void _reset() { timer?.cancel(); setState(() { timer = null; seconds = initial; }); }
}

class StopwatchPageX extends StatefulWidget {
  const StopwatchPageX({super.key});
  @override
  State<StopwatchPageX> createState() => _StopwatchPageXState();
}

class _StopwatchPageXState extends State<StopwatchPageX> {
  final sw = Stopwatch();
  Timer? ticker;
  final List<String> laps = [];

  @override
  void dispose() {
    ticker?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final text = _elapsedText();
    return AppPage(
      title: 'کرنومتر حرفه‌ای',
      icon: Icons.av_timer_rounded,
      colors: const [Color(0xff667eea), Color(0xff764ba2)],
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          padding: const EdgeInsets.all(24),
          decoration: gradientDecoration(const [Color(0xff667eea), Color(0xff764ba2)], radius: 34),
          child: Column(children: [
            Container(width: 170, height: 170, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white.withOpacity(.42), width: 10), color: Colors.white.withOpacity(.12)), child: const Icon(Icons.speed_rounded, size: 82, color: Colors.white)),
            const SizedBox(height: 16),
            Text(text, style: const TextStyle(color: Colors.white, fontSize: 44, fontWeight: FontWeight.w900)),
            const Text('دقیقه : ثانیه . صدم ثانیه', style: TextStyle(color: Colors.white70)),
          ]),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: softDecoration(radius: 28),
          child: Wrap(alignment: WrapAlignment.center, spacing: 10, runSpacing: 10, children: [
            FilledButton.icon(onPressed: _startPause, icon: Icon(sw.isRunning ? Icons.pause_rounded : Icons.play_arrow_rounded), label: Text(sw.isRunning ? 'توقف' : 'شروع')),
            OutlinedButton.icon(onPressed: _lap, icon: const Icon(Icons.flag_rounded), label: const Text('ثبت دور')),
            OutlinedButton.icon(onPressed: _reset, icon: const Icon(Icons.replay_rounded), label: const Text('ریست')),
          ]),
        ),
        if (laps.isNotEmpty) ...[
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: softDecoration(radius: 28),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('دورهای ثبت‌شده', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
              const SizedBox(height: 8),
              ...laps.asMap().entries.map((e) => Container(width: double.infinity, margin: const EdgeInsets.only(top: 8), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xfff3f4ff), borderRadius: BorderRadius.circular(16)), child: Text('دور ${faNum(e.key + 1)}   ${e.value}', style: const TextStyle(fontWeight: FontWeight.w900)))).toList(),
            ]),
          ),
        ],
      ]),
    );
  }

  String _elapsedText() {
    final e = sw.elapsed;
    return '${faNum(e.inMinutes.toString().padLeft(2, '0'))}:${faNum((e.inSeconds % 60).toString().padLeft(2, '0'))}.${faNum(((e.inMilliseconds % 1000) ~/ 10).toString().padLeft(2, '0'))}';
  }

  void _startPause() {
    if (sw.isRunning) {
      sw.stop();
    } else {
      sw.start();
      ticker ??= Timer.periodic(const Duration(milliseconds: 35), (_) { if (mounted) setState(() {}); });
    }
    setState(() {});
  }

  void _lap() {
    if (sw.elapsedMilliseconds > 0) setState(() => laps.insert(0, _elapsedText()));
  }

  void _reset() {
    sw.reset();
    sw.stop();
    ticker?.cancel();
    ticker = null;
    setState(() => laps.clear());
  }
}

class CounterPage extends StatefulWidget {
  const CounterPage({super.key});
  @override
  State<CounterPage> createState() => _CounterPageState();
}

class _CounterPageState extends State<CounterPage> {
  int value = 0;
  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'شمارنده',
      icon: Icons.add_circle_rounded,
      colors: const [Color(0xffff512f), Color(0xffdd2476)],
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        decoration: softDecoration(radius: 30),
        child: Column(children: [
          Text(faNum(value), style: const TextStyle(fontSize: 78, fontWeight: FontWeight.w900)),
          const SizedBox(height: 16),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            IconButton.filled(onPressed: () => setState(() => value++), iconSize: 34, icon: const Icon(Icons.add_rounded)),
            const SizedBox(width: 18),
            IconButton.outlined(onPressed: () => setState(() => value = value > 0 ? value - 1 : 0), iconSize: 34, icon: const Icon(Icons.remove_rounded)),
          ]),
        ]),
      ),
    );
  }
}

// ------------------------- Dice, Coin, Lottery -------------------------

class DicePage extends StatefulWidget {
  const DicePage({super.key});
  @override
  State<DicePage> createState() => _DicePageState();
}

class _DicePageState extends State<DicePage> with SingleTickerProviderStateMixin {
  late final AnimationController controller;
  int face = 1;
  bool rolling = false;
  final rnd = math.Random();

  @override
  void initState() {
    super.initState();
    controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1700))
      ..addListener(() {
        if (rolling && controller.value < .82 && (controller.value * 100).round() % 7 == 0) {
          setState(() => face = rnd.nextInt(6) + 1);
        }
      })
      ..addStatusListener((status) {
        if (status == AnimationStatus.completed) { setState(() { rolling = false; face = rnd.nextInt(6) + 1; }); HapticFeedback.mediumImpact(); }
      });
  }

  @override
  void dispose() { controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'تاس واقعی سه‌بعدی',
      icon: Icons.casino_rounded,
      colors: const [Color(0xfff7971e), Color(0xffffd200)],
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          height: 360,
          padding: const EdgeInsets.all(22),
          decoration: gradientDecoration(const [Color(0xffffd200), Color(0xfff7971e)], radius: 34),
          child: AnimatedBuilder(
            animation: controller,
            builder: (_, __) {
              final t = Curves.easeOutCubic.transform(controller.value);
              final bounce = rolling ? math.sin(controller.value * math.pi * 5).abs() * (1 - t) * 28 : 0.0;
              final slide = rolling ? math.sin(controller.value * math.pi * 2) * (1 - t) * 22 : 0.0;
              return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Transform.translate(
                  offset: Offset(slide, -bounce),
                  child: RealDiceCube(face: face, progress: controller.value, rolling: rolling),
                ),
                const SizedBox(height: 28),
                Text('نتیجه: ${faNum(face)}', style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900)),
              ]);
            },
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: rolling ? null : _roll, icon: const Icon(Icons.casino_rounded), label: const Text('پرتاب تاس'))),
      ]),
    );
  }

  void _roll() { HapticFeedback.selectionClick(); setState(() => rolling = true); controller.forward(from: 0); }
}

class RealDiceCube extends StatelessWidget {
  final int face;
  final double progress;
  final bool rolling;
  const RealDiceCube({super.key, required this.face, required this.progress, required this.rolling});

  @override
  Widget build(BuildContext context) {
    final t = Curves.easeOutCubic.transform(progress);
    final angle = rolling ? (1 - t) * math.pi * 7 : 0.0;
    return SizedBox(
      width: 230,
      height: 230,
      child: Stack(alignment: Alignment.center, children: [
        Positioned(bottom: 28, child: AnimatedContainer(duration: const Duration(milliseconds: 100), width: rolling ? 150 + 30 * t : 155, height: rolling ? 24 + 8 * t : 28, decoration: BoxDecoration(color: Colors.black.withOpacity(.22), borderRadius: BorderRadius.circular(100), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.22), blurRadius: 28)]))),
        Transform(
          alignment: Alignment.center,
          transform: Matrix4.identity()
            ..setEntry(3, 2, .0012)
            ..rotateX(.18 + math.sin(angle) * .22)
            ..rotateY(-.22 + math.cos(angle) * .18)
            ..rotateZ(rolling ? math.sin(angle) * .20 : 0),
          child: CustomPaint(size: const Size(170, 170), painter: SolidDicePainter(face)),
        ),
      ]),
    );
  }
}

class SolidDicePainter extends CustomPainter {
  final int face;
  SolidDicePainter(this.face);
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final frontRect = Rect.fromLTWH(w * .22, h * .26, w * .48, h * .48);
    final topOffset = Offset(w * .14, -h * .12);

    final front = RRect.fromRectAndRadius(frontRect, const Radius.circular(24));
    final topPath = Path()
      ..moveTo(frontRect.left, frontRect.top)
      ..lineTo(frontRect.left + topOffset.dx, frontRect.top + topOffset.dy)
      ..lineTo(frontRect.right + topOffset.dx, frontRect.top + topOffset.dy)
      ..lineTo(frontRect.right, frontRect.top)
      ..close();
    final sidePath = Path()
      ..moveTo(frontRect.right, frontRect.top)
      ..lineTo(frontRect.right + topOffset.dx, frontRect.top + topOffset.dy)
      ..lineTo(frontRect.right + topOffset.dx, frontRect.bottom + topOffset.dy)
      ..lineTo(frontRect.right, frontRect.bottom)
      ..close();

    canvas.drawShadow(Path()..addRRect(front), Colors.black.withOpacity(.22), 18, false);
    canvas.drawShadow(topPath, Colors.black.withOpacity(.12), 10, false);
    canvas.drawShadow(sidePath, Colors.black.withOpacity(.14), 12, false);

    canvas.drawPath(topPath, Paint()..shader = const LinearGradient(colors: [Color(0xffffffff), Color(0xffedf2ff)]).createShader(Rect.fromLTWH(0, 0, w, h)));
    canvas.drawPath(sidePath, Paint()..shader = const LinearGradient(colors: [Color(0xffe5ebfb), Color(0xffcad5f6)]).createShader(Rect.fromLTWH(0, 0, w, h)));
    canvas.drawRRect(front, Paint()..shader = const LinearGradient(colors: [Color(0xffffffff), Color(0xfff4f7ff)], begin: Alignment.topLeft, end: Alignment.bottomRight).createShader(frontRect));

    final stroke = Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = Colors.white.withOpacity(.9);
    canvas.drawPath(topPath, stroke);
    canvas.drawPath(sidePath, stroke);
    canvas.drawRRect(front, stroke);

    final dotPaint = Paint()..color = const Color(0xff0f172a);
    final positions = {
      'tl': Offset(frontRect.left + frontRect.width * .22, frontRect.top + frontRect.height * .22),
      'tr': Offset(frontRect.left + frontRect.width * .78, frontRect.top + frontRect.height * .22),
      'ml': Offset(frontRect.left + frontRect.width * .22, frontRect.top + frontRect.height * .50),
      'c': Offset(frontRect.left + frontRect.width * .50, frontRect.top + frontRect.height * .50),
      'mr': Offset(frontRect.left + frontRect.width * .78, frontRect.top + frontRect.height * .50),
      'bl': Offset(frontRect.left + frontRect.width * .22, frontRect.top + frontRect.height * .78),
      'br': Offset(frontRect.left + frontRect.width * .78, frontRect.top + frontRect.height * .78),
    };
    late final List<Offset> dots;
    switch (face) {
      case 1: dots = [positions['c']!]; break;
      case 2: dots = [positions['tl']!, positions['br']!]; break;
      case 3: dots = [positions['tl']!, positions['c']!, positions['br']!]; break;
      case 4: dots = [positions['tl']!, positions['tr']!, positions['bl']!, positions['br']!]; break;
      case 5: dots = [positions['tl']!, positions['tr']!, positions['c']!, positions['bl']!, positions['br']!]; break;
      default: dots = [positions['tl']!, positions['tr']!, positions['ml']!, positions['mr']!, positions['bl']!, positions['br']!];
    }
    for (final p in dots) {
      canvas.drawCircle(p, 8.5, dotPaint);
    }
    canvas.drawCircle(Offset(frontRect.left + frontRect.width * .30, frontRect.top + frontRect.height * .18), 5.5, Paint()..color = Colors.white.withOpacity(.92));
  }
  @override
  bool shouldRepaint(covariant SolidDicePainter oldDelegate) => oldDelegate.face != face;
}

class CoinPage extends StatefulWidget {
  const CoinPage({super.key});
  @override
  State<CoinPage> createState() => _CoinPageState();
}

class _CoinPageState extends State<CoinPage> with SingleTickerProviderStateMixin {
  late final AnimationController controller;
  final rnd = math.Random();
  String result = '؟';
  String targetResult = 'شیر';
  bool flipping = false;

  @override
  void initState() {
    super.initState();
    controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1850))
      ..addStatusListener((status) {
        if (status == AnimationStatus.completed) { setState(() { flipping = false; result = targetResult; }); HapticFeedback.lightImpact(); }
      });
  }
  @override
  void dispose() { controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'شیر یا خط',
      icon: Icons.monetization_on_rounded,
      colors: const [Color(0xfff6d365), Color(0xfffda085)],
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          height: 360,
          padding: const EdgeInsets.all(22),
          decoration: gradientDecoration(const [Color(0xfff6d365), Color(0xfffda085)], radius: 34),
          child: AnimatedBuilder(
            animation: controller,
            builder: (_, __) {
              final t = Curves.easeOutCubic.transform(controller.value);
              final height = math.sin(controller.value * math.pi) * 76;
              final spins = targetResult == 'شیر' ? 14 : 15;
              final angle = controller.value * math.pi * spins;
              final showFront = flipping ? math.cos(angle) >= 0 : result != 'خط';
              return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Transform.translate(
                  offset: Offset(0, -height),
                  child: Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.identity()..setEntry(3, 2, .0017)..rotateX(.24 * math.sin(controller.value * math.pi))..rotateY(angle)..rotateZ((1 - t) * .18),
                    child: Transform(
                      alignment: Alignment.center,
                      transform: Matrix4.identity()..rotateY(showFront ? 0 : math.pi),
                      child: RealisticCoin(text: showFront ? 'شیر' : 'خط', sideAmount: math.sin(angle).abs()),
                    ),
                  ),
                ),
                const SizedBox(height: 30),
                Text('نتیجه: $result', style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900)),
              ]);
            },
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: flipping ? null : _flip, icon: const Icon(Icons.flip_rounded), label: const Text('پرتاب سکه'))),
      ]),
    );
  }

  void _flip() { HapticFeedback.selectionClick(); setState(() { flipping = true; targetResult = rnd.nextBool() ? 'شیر' : 'خط'; result = '...'; }); controller.forward(from: 0); }
}

class RealisticCoin extends StatelessWidget {
  final String text;
  final double sideAmount;
  const RealisticCoin({super.key, required this.text, required this.sideAmount});
  @override
  Widget build(BuildContext context) {
    final thickness = 12 + sideAmount * 22;
    return SizedBox(
      width: 190,
      height: 190,
      child: Stack(alignment: Alignment.center, children: [
        Positioned(bottom: 14, child: Container(width: 140, height: 24, decoration: BoxDecoration(color: Colors.black.withOpacity(.20), borderRadius: BorderRadius.circular(80), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.22), blurRadius: 28)]))),
        Transform.translate(offset: Offset(thickness / 4, thickness / 7), child: Container(width: 158, height: 158, decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xffb66a00), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.20), blurRadius: 18, offset: const Offset(0, 10))]))),
        Container(width: 166, height: 166, decoration: BoxDecoration(shape: BoxShape.circle, gradient: const RadialGradient(colors: [Color(0xfffff1a3), Color(0xffffc233), Color(0xffd68600)], center: Alignment.topLeft), border: Border.all(color: const Color(0xfffff3bd), width: 7), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.18), blurRadius: 20, offset: const Offset(0, 12))]), child: CustomPaint(painter: CoinPatternPainter(text))),
      ]),
    );
  }
}

class CoinPatternPainter extends CustomPainter {
  final String text;
  CoinPatternPainter(this.text);
  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final p = Paint()..style = PaintingStyle.stroke..strokeWidth = 3..color = Colors.white.withOpacity(.70);
    canvas.drawCircle(c, size.width * .36, p);
    canvas.drawCircle(c, size.width * .25, p..color = Colors.white.withOpacity(.42));
    canvas.drawCircle(Offset(size.width * .35, size.height * .30), 10, Paint()..color = Colors.white.withOpacity(.45));
    final tp = TextPainter(text: TextSpan(text: text, style: const TextStyle(color: Color(0xff684000), fontSize: 34, fontWeight: FontWeight.w900)), textDirection: TextDirection.rtl)..layout();
    tp.paint(canvas, c - Offset(tp.width / 2, tp.height / 2));
  }
  @override
  bool shouldRepaint(covariant CoinPatternPainter oldDelegate) => oldDelegate.text != text;
}

class LotteryPage extends StatefulWidget {
  const LotteryPage({super.key});
  @override
  State<LotteryPage> createState() => _LotteryPageState();
}

class _LotteryPageState extends State<LotteryPage> with SingleTickerProviderStateMixin {
  final nameController = TextEditingController();
  List<String> names = [];
  List<String> wheelNames = [];
  List<String> winners = [];
  List<String> history = [];
  int winnerCount = 1;
  bool removeWinner = true;
  bool running = false;
  double rotation = 0;
  int selectedIndex = 0;
  late final AnimationController wheelController;
  Animation<double>? wheelAnimation;
  final rnd = math.Random();

  @override
  void initState() {
    super.initState();
    wheelController = AnimationController(vsync: this, duration: const Duration(milliseconds: 3400))
      ..addListener(() { if (wheelAnimation != null) setState(() => rotation = wheelAnimation!.value); })
      ..addStatusListener((status) { if (status == AnimationStatus.completed) _finishOneSpin(); });
    _loadHistory();
  }

  @override
  void dispose() { nameController.dispose(); wheelController.dispose(); super.dispose(); }

  Future<void> _loadHistory() async { final prefs = await SharedPreferences.getInstance(); setState(() => history = prefs.getStringList('lottery_history') ?? []); }
  Future<void> _saveHistory() async { final prefs = await SharedPreferences.getInstance(); await prefs.setStringList('lottery_history', history); }

  @override
  Widget build(BuildContext context) {
    final wheelList = running ? wheelNames : (names.isEmpty ? ['آماده'] : names);
    return AppPage(
      title: 'قرعه‌کشی گردونه‌ای',
      icon: Icons.celebration_rounded,
      colors: const [Color(0xfffa709a), Color(0xffffc371)],
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: gradientDecoration(const [Color(0xfffa709a), Color(0xffffc371)], radius: 34),
          child: Column(children: [
            SizedBox(
              height: 270,
              child: Stack(alignment: Alignment.center, children: [
                Positioned(top: 0, child: Container(width: 34, height: 52, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.18), blurRadius: 14)]), child: const Icon(Icons.arrow_drop_down_rounded, color: Color(0xfffa709a), size: 36))),
                Transform.rotate(angle: rotation, child: CustomPaint(size: const Size(240, 240), painter: WheelPainter(wheelList))),
                Container(width: 74, height: 74, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white, boxShadow: [BoxShadow(color: Colors.black.withOpacity(.15), blurRadius: 18)]), child: const Icon(Icons.emoji_events_rounded, color: Color(0xffff9a00), size: 38)),
              ]),
            ),
            Text(winners.isEmpty ? 'تعداد شرکت‌کننده‌ها: ${faNum(names.length)}' : 'برنده آخر: ${winners.last}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)),
            const SizedBox(height: 6),
            const Text('همه بخش‌های گردونه شانس برابر دارند', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700)),
          ]),
        ),
        const SizedBox(height: 14),
        TextField(controller: nameController, minLines: 1, maxLines: 1, textInputAction: TextInputAction.done, onSubmitted: (_) { if (!running) _addNames(); }, decoration: fieldDecoration('افزودن شرکت‌کننده', hint: 'نام را وارد کن و Enter بزن...', icon: Icons.person_add_rounded)),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: FilledButton.icon(onPressed: running ? null : _addNames, icon: const Icon(Icons.add_rounded), label: const Text('افزودن'))),
          const SizedBox(width: 10),
          Expanded(child: OutlinedButton.icon(onPressed: running ? null : () => setState(() { names.clear(); wheelNames.clear(); winners.clear(); }), icon: const Icon(Icons.cleaning_services_rounded), label: const Text('پاک کردن'))),
        ]),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: softDecoration(radius: 26),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('تعداد برنده‌ها: ${faNum(winnerCount)}', style: const TextStyle(fontWeight: FontWeight.w900)),
            Slider(value: winnerCount.toDouble().clamp(1.0, math.max(1, names.length).toDouble()).toDouble(), min: 1, max: math.max(1, names.length).toDouble(), divisions: math.max(1, names.length - 1), onChanged: names.isEmpty ? null : (v) => setState(() => winnerCount = v.round())),
            SwitchListTile(value: removeWinner, onChanged: running ? null : (v) => setState(() => removeWinner = v), title: const Text('برنده بعد از انتخاب از گردونه حذف شود', style: TextStyle(fontWeight: FontWeight.w800))),
            Wrap(spacing: 8, runSpacing: 8, children: List.generate(names.length, (i) => Chip(label: Text(names[i]), deleteIcon: const Icon(Icons.close_rounded), onDeleted: running ? null : () => setState(() { names.removeAt(i); winnerCount = winnerCount.clamp(1, math.max(1, names.length)).toInt(); }))))
          ]),
        ),
        const SizedBox(height: 14),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: running ? null : _startLottery, icon: const Icon(Icons.casino_rounded), label: const Text('چرخاندن گردونه'))),
        if (winners.isNotEmpty) ...[
          resultCard('برنده‌ها', winners.map((e) => '🏆 $e').join('\n'), icon: Icons.emoji_events_rounded, colors: const [Color(0xff00b894), Color(0xff55efc4)]),
          const SizedBox(height: 8),
          Row(children: [Expanded(child: OutlinedButton.icon(onPressed: () => Clipboard.setData(ClipboardData(text: winners.join('\n'))), icon: const Icon(Icons.copy_rounded), label: const Text('کپی نتیجه'))), const SizedBox(width: 10), Expanded(child: OutlinedButton.icon(onPressed: _storeResult, icon: const Icon(Icons.save_rounded), label: const Text('ذخیره')))]),
        ],
      ]),
    );
  }

  void _addNames() {
    final entered = nameController.text
        .split(RegExp(r'[\n\r،,;]+'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
    if (entered.isEmpty) return;
    final existing = names.toSet();
    final cleaned = entered.where((e) => !existing.contains(e)).toList();
    if (cleaned.isEmpty) {
      nameController.clear();
      return;
    }
    setState(() {
      names.addAll(cleaned);
      winnerCount = winnerCount.clamp(1, math.max(1, names.length)).toInt();
      nameController.clear();
    });
  }

  void _startLottery() {
    _addNames();
    if (names.length < winnerCount || names.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعداد شرکت‌کننده‌ها کافی نیست'))); return; }
    setState(() { winners.clear(); wheelNames = [...names]; running = true; });
    _spinNext();
  }

  void _spinNext() {
    if (wheelNames.isEmpty || winners.length >= winnerCount) { setState(() => running = false); return; }
    selectedIndex = rnd.nextInt(wheelNames.length);
    final seg = math.pi * 2 / wheelNames.length;
    final currentNorm = rotation % (math.pi * 2);
    final desired = -((selectedIndex + .5) * seg);
    final delta = (desired - currentNorm) % (math.pi * 2);
    final extra = math.pi * 2 * (6 + rnd.nextInt(3));
    final target = rotation + extra + delta;
    wheelAnimation = Tween<double>(begin: rotation, end: target).animate(CurvedAnimation(parent: wheelController, curve: Curves.easeOutQuart));
    wheelController.forward(from: 0);
  }

  void _finishOneSpin() {
    if (wheelNames.isEmpty) return;
    final safeIndex = selectedIndex.clamp(0, wheelNames.length - 1).toInt();
    final picked = wheelNames[safeIndex];
    setState(() { winners.add(picked); if (removeWinner) wheelNames.removeAt(safeIndex); });
    HapticFeedback.mediumImpact();
    if (winners.length < winnerCount) { Future.delayed(const Duration(milliseconds: 650), () { if (mounted) _spinNext(); }); } else { setState(() => running = false); }
  }

  void _storeResult() { if (winners.isEmpty) return; final text = '${PersianDateUtils.today().longText}: ${winners.join('، ')}'; setState(() => history.insert(0, text)); _saveHistory(); }
}

class WheelPainter extends CustomPainter {
  final List<String> names;
  WheelPainter(this.names);
  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2;
    final safeNames = names.isEmpty ? ['آماده'] : names;
    final seg = math.pi * 2 / safeNames.length;
    final colors = [const Color(0xfffa709a), const Color(0xffffc371), const Color(0xff6d5dfc), const Color(0xff22d3ee), const Color(0xff00b894), const Color(0xffff7675)];
    for (var i = 0; i < safeNames.length; i++) {
      final paint = Paint()..color = colors[i % colors.length];
      canvas.drawArc(Rect.fromCircle(center: c, radius: r), -math.pi / 2 + i * seg, seg, true, paint);
      final textAngle = -math.pi / 2 + i * seg + seg / 2;
      canvas.save();
      canvas.translate(c.dx + math.cos(textAngle) * r * .58, c.dy + math.sin(textAngle) * r * .58);
      canvas.rotate(textAngle + math.pi / 2);
      final tp = TextPainter(text: TextSpan(text: safeNames[i], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 12)), textDirection: TextDirection.rtl, maxLines: 1, ellipsis: '...')..layout(maxWidth: r * .58);
      tp.paint(canvas, Offset(-tp.width / 2, -tp.height / 2));
      canvas.restore();
    }
    canvas.drawCircle(c, r, Paint()..style = PaintingStyle.stroke..strokeWidth = 8..color = Colors.white.withOpacity(.88));
    canvas.drawCircle(c, r - 12, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = Colors.white.withOpacity(.40));
  }
  @override
  bool shouldRepaint(covariant WheelPainter oldDelegate) => oldDelegate.names.join('|') != names.join('|');
}

class DeviceInfoPage extends StatefulWidget {
  const DeviceInfoPage({super.key});
  @override
  State<DeviceInfoPage> createState() => _DeviceInfoPageState();
}

class _DeviceInfoPageState extends State<DeviceInfoPage> {
  late Future<List<_DeviceInfoRow>> future;

  @override
  void initState() { super.initState(); future = _load(); }

  Future<List<_DeviceInfoRow>> _load() async {
    final rows = <_DeviceInfoRow>[];
    final today = PersianDateUtils.today();
    try {
      final package = await PackageInfo.fromPlatform();
      rows.add(_DeviceInfoRow(Icons.verified_rounded, 'نسخه برنامه', '${package.version}+${package.buildNumber}'));
    } catch (_) { rows.add(_DeviceInfoRow(Icons.verified_rounded, 'نسخه برنامه', 'قابل دریافت نیست')); }
    try {
      if (Platform.isAndroid) {
        final info = await DeviceInfoPlugin().androidInfo;
        rows.add(_DeviceInfoRow(Icons.phone_android_rounded, 'مدل گوشی', '${info.manufacturer} ${info.model}'));
        rows.add(_DeviceInfoRow(Icons.memory_rounded, 'نسخه اندروید', 'Android ${info.version.release} / SDK ${info.version.sdkInt}'));
        rows.add(_DeviceInfoRow(Icons.precision_manufacturing_rounded, 'برند و سازنده', '${info.brand} / ${info.manufacturer}'));
        rows.add(_DeviceInfoRow(Icons.devices_rounded, 'نام دستگاه', info.device));
      } else {
        rows.add(_DeviceInfoRow(Icons.phone_android_rounded, 'سیستم عامل', Platform.operatingSystem));
      }
    } catch (_) { rows.add(_DeviceInfoRow(Icons.phone_android_rounded, 'اطلاعات گوشی', 'دسترسی/پشتیبانی نشد')); }
    try {
      final battery = Battery();
      final level = await battery.batteryLevel;
      final state = await battery.batteryState;
      rows.add(_DeviceInfoRow(Icons.battery_full_rounded, 'باتری', '${faNum(level)}٪ - ${_batteryStateText(state)}'));
    } catch (_) { rows.add(_DeviceInfoRow(Icons.battery_unknown_rounded, 'باتری', 'قابل دریافت نیست')); }
    try {
      final connectivity = await Connectivity().checkConnectivity();
      rows.add(_DeviceInfoRow(Icons.wifi_rounded, 'وضعیت اینترنت', _connectionText(connectivity)));
    } catch (_) { rows.add(_DeviceInfoRow(Icons.wifi_off_rounded, 'وضعیت اینترنت', 'قابل دریافت نیست')); }
    final mq = MediaQuery.of(context);
    rows.add(_DeviceInfoRow(Icons.aspect_ratio_rounded, 'صفحه نمایش', '${faNum(mq.size.width.toStringAsFixed(0))} × ${faNum(mq.size.height.toStringAsFixed(0))} logical px'));
    rows.add(_DeviceInfoRow(Icons.language_rounded, 'زبان و منطقه', '${Localizations.localeOf(context).languageCode} - ${Localizations.localeOf(context).countryCode ?? 'نامشخص'}'));
    rows.add(_DeviceInfoRow(Icons.calendar_month_rounded, 'تاریخ شمسی امروز', today.longText));
    rows.add(_DeviceInfoRow(Icons.access_time_rounded, 'ساعت سیستم', faNum(TimeOfDay.now().format(context))));
    return rows;
  }

  String _batteryStateText(BatteryState state) {
    switch (state) {
      case BatteryState.charging: return 'در حال شارژ';
      case BatteryState.discharging: return 'در حال مصرف';
      case BatteryState.full: return 'کامل';
      case BatteryState.connectedNotCharging: return 'وصل است، اما شارژ نمی‌شود';
      case BatteryState.unknown: return 'نامشخص';
      default: return 'نامشخص';
    }
  }

  String _connectionText(dynamic value) {
    final text = value.toString();
    if (text.contains('wifi')) return 'وای‌فای';
    if (text.contains('mobile')) return 'داده موبایل';
    if (text.contains('ethernet')) return 'اترنت';
    if (text.contains('none')) return 'قطع';
    return text.replaceAll('ConnectivityResult.', '').replaceAll('[', '').replaceAll(']', '');
  }

  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: 'اطلاعات دستگاه',
      icon: Icons.phone_android_rounded,
      colors: const [Color(0xff36d1dc), Color(0xff5b86e5)],
      child: FutureBuilder<List<_DeviceInfoRow>>(
        future: future,
        builder: (context, snap) {
          if (!snap.hasData) return Container(padding: const EdgeInsets.all(24), decoration: softDecoration(radius: 28), child: const Center(child: CircularProgressIndicator()));
          return Column(children: snap.data!.map((e) => _infoTile(e.icon, e.title, e.value)).toList());
        },
      ),
    );
  }

  Widget _infoTile(IconData icon, String title, String subtitle) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: softDecoration(radius: 22),
      child: Row(children: [Container(padding: const EdgeInsets.all(11), decoration: gradientDecoration(const [Color(0xff36d1dc), Color(0xff5b86e5)], radius: 16), child: Icon(icon, color: Colors.white)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900)), Text(subtitle, style: TextStyle(color: Colors.grey.shade600, height: 1.4))]))]),
    );
  }
}

class _DeviceInfoRow {
  final IconData icon;
  final String title;
  final String value;
  const _DeviceInfoRow(this.icon, this.title, this.value);
}

class ComingSoonPage extends StatelessWidget {
  final String title;
  const ComingSoonPage({super.key, required this.title});
  @override
  Widget build(BuildContext context) {
    return AppPage(
      title: title,
      icon: Icons.build_circle_rounded,
      colors: const [Color(0xff30cfd0), Color(0xff330867)],
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        decoration: softDecoration(radius: 30),
        child: const Text('این بخش در نسخه‌های بعد با دسترسی‌های لازم گوشی و پکیج‌های اختصاصی کامل می‌شود. نسخه فعلی روی ابزارهای سریع، آفلاین، شمسی و کاربردی تمرکز دارد.', style: TextStyle(fontSize: 16, height: 1.8)),
      ),
    );
  }
}
