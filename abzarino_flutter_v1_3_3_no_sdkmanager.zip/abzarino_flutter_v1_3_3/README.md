# ابزارینو v1.3.3+7

نسخه اصلاحی برای build در GitHub Actions بدون استفاده از sdkmanager.

اصلاحات:
- حذف کامل مرحله sdkmanager از workflow.
- تنظیم build روی compileSdk/targetSdk 34 برای سازگاری با runner فعلی.
- قفل کردن flutter_plugin_android_lifecycle روی 2.0.24 تا خطای نیاز به SDK 35 ایجاد نشود.
- حفظ اصلاح BatteryState.connectedNotCharging.
- خروجی APK/AAB با نسخه 1.3.3+7.
